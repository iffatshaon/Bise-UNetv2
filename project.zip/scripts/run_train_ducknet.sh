#!/bin/bash
export PYTHONPATH=$PYTHONPATH:$(pwd)
source ../.venv/bin/activate

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"

python3 -m train.train \
    --model ducknet \
    --data-dir "$DATA_DIR" \
    --out-dir results/ducknet_run \
    --epochs 200 \
    --batch 4 \
    --mixed \
    --patience 15
