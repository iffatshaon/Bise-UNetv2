#!/bin/bash
source ../.venv/bin/activate
# Must be run from Kvasir-structured directory
export PYTHONPATH=$PYTHONPATH:$(pwd)

MODEL=$1
if [ -z "$MODEL" ]; then
    echo "Usage: ./scripts/run_eval_generic.sh <model_name>"
    exit 1
fi

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"
CKPT="results/${MODEL}_run/best.pt"

if [ ! -f "$CKPT" ]; then
    echo "Checkpoint not found: $CKPT"
    exit 1
fi

echo "Running evaluation for model: $MODEL"
echo "Checkpoint: $CKPT"

python3 -m postprocess.evaluate \
    --model "$MODEL" \
    --ckpt "$CKPT" \
    --data-dir "$DATA_DIR"

