#!/bin/bash
# Universal Training Script
# Usage: ./run_train_universal.sh --model <name> --dataset <path> --out-dir <path> [options]

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $DIR/../../.venv/bin/activate
export PYTHONPATH=$PYTHONPATH:$DIR/..

# Defaults
MODULE="train.train"
EPOCHS=200
BATCH=8
PATIENCE=15
MIXED=true

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --model) MODEL="$2"; shift ;;
        --dataset) DATA_DIR="$2"; shift ;;
        --out-dir) OUT_DIR="$2"; shift ;;
        --module) MODULE="$2"; shift ;;
        --epochs) EPOCHS="$2"; shift ;;
        --batch) BATCH="$2"; shift ;;
        --patience) PATIENCE="$2"; shift ;;
        --no-mixed) MIXED=false ;;
        *) EXTRA_ARGS="$EXTRA_ARGS $1" ;;
    esac
    shift
done

if [ -z "$MODEL" ] || [ -z "$DATA_DIR" ] || [ -z "$OUT_DIR" ]; then
    echo "Error: Missing required arguments."
    echo "Usage: $0 --model <name> --dataset <path> --out-dir <path> [--module <train.train>] ..."
    exit 1
fi

CMD="python3 -m $MODULE \
    --model $MODEL \
    --data-dir \"$DATA_DIR\" \
    --out-dir \"$OUT_DIR\" \
    --epochs $EPOCHS \
    --batch $BATCH \
    --patience $PATIENCE \
    $EXTRA_ARGS"

if [ "$MIXED" = true ]; then
    CMD="$CMD --mixed"
fi

echo "Executing: $CMD"
eval $CMD
