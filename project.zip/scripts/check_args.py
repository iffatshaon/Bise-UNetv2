
import torch
import sys

ckpt_path = sys.argv[1]
checkpoint = torch.load(ckpt_path, map_location='cpu')
if 'args' in checkpoint:
    print(checkpoint['args'])
else:
    print("No args found in checkpoint.")
