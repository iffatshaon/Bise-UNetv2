#!/bin/bash
source ../.venv/bin/activate
# Dry run verification
export PYTHONPATH=$PYTHONPATH:$(pwd)

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"

echo "Running dry run..."
python3 -m train.train \
    --model unet \
    --data-dir "$DATA_DIR" \
    --out-dir results/dry_run \
    --epochs 1 \
    --batch 2 \
    --img-size 128 \
    --patience 1 \
    --workers 0 # Avoid multiprocessing issues in dry run if any

echo "Dry run train finished."

if [ -f "results/dry_run/best.pt" ]; then
    echo "Running dry run eval..."
    python3 -m postprocess.evaluate \
        --model unet \
        --ckpt results/dry_run/best.pt \
        --data-dir "$DATA_DIR" \
        --img-size 128 \
        --benchmark
    echo "Dry run eval finished."
else
    echo "Training failed to produce checkpoint."
    exit 1
fi
