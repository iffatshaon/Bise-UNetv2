import os
import subprocess
import argparse

# Configuration Registry
DATASETS = {
    "kvasir": {
        "path": "/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG",
        "train_module": "train.train",
        "eval_module": "postprocess.evaluate",
        "results_root": "results/kvasir"
    },
    "ldpolyp": {
        "path": "/media/iffat/DataDrive/dataset/LDPolyp",
        "train_module": "train.train_ldpolyp",
        "eval_module": "postprocess.evaluate_ldpolyp",
        "results_root": "results/ldpolyp"
    },
    "combined": {
        "path": "/media/iffat/DataDrive/dataset/CombinedDataset",
        "train_module": "train.train_combined",
        "eval_module": "postprocess.evaluate",
        "results_root": "results/combined"
    }
}

ALL_MODELS = [
    "bisenet",
    "biseunetv1", "biseunetv2", "biseunetv3", "biseunetv4", "biseunetv5", "biseunetv6", "biseunetv7",
    "ducknet",
    "hardnet", "hardunet",
    "unet",
    "rfdetr",
    "eomt",
]

def run_command(cmd):
    print(f"\n[EXEC] {cmd}")
    ret = subprocess.call(cmd, shell=True)
    return ret == 0

def main():
    parser = argparse.ArgumentParser(description="Universal Pipeline Runner")
    parser.add_argument("--dataset", type=str, required=True, choices=DATASETS.keys(), help="Dataset key")
    parser.add_argument("--models", type=str, nargs="+", default=ALL_MODELS, help="List of models to run")
    parser.add_argument("--skip-train", action="store_true", help="Skip training phase")
    parser.add_argument("--skip-eval", action="store_true", help="Skip evaluation phase")
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--batch", type=int, default=8)
    parser.add_argument("--results-dir", type=str, default=None, help="Override results root dir")
    
    args = parser.parse_args()
    
    config = DATASETS[args.dataset]
    print(f"Running pipeline for dataset: {args.dataset}")
    print(f"Data Path: {config['path']}")
    print(f"Models: {args.models}")
    
    results_root = args.results_dir if args.results_dir else config["results_root"]
    os.makedirs(results_root, exist_ok=True)
    
    for model in args.models:
        print(f"\n>>> Processing Model: {model}")
        out_dir = os.path.join(results_root, f"{model}_run")
        
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 1. Training
        if not args.skip_train:
            train_script = os.path.join(script_dir, "run_train_universal.sh")
            train_cmd = (
                f"bash {train_script} "
                f"--model {model} "
                f"--dataset \"{config['path']}\" "
                f"--out-dir \"{out_dir}\" "
                f"--module {config['train_module']} "
                f"--epochs {args.epochs} "
                f"--batch {args.batch}"
            )
            
            if not run_command(train_cmd):
                print(f"!!! Training Failed for {model}. Skipping evaluation.")
                continue
        else:
            print("Skipping training...")

        # 2. Evaluation
        if not args.skip_eval:
            ckpt = os.path.join(out_dir, "best.pt")
            if not os.path.exists(ckpt):
                print(f"!!! Checkpoint not found: {ckpt}. Skipping evaluation.")
                continue
                
            eval_script = os.path.join(script_dir, "run_eval_universal.sh")
            eval_cmd = (
                f"bash {eval_script} "
                f"--model {model} "
                f"--dataset \"{config['path']}\" "
                f"--ckpt \"{ckpt}\" "
                f"--out-dir \"{out_dir}\" "
                f"--module {config['eval_module']}"
            )
            
            if not run_command(eval_cmd):
                print(f"!!! Evaluation Failed for {model}.")
        else:
            print("Skipping evaluation...")

if __name__ == "__main__":
    main()
