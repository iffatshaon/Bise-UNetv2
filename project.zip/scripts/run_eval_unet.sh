#!/bin/bash
source ../.venv/bin/activate
# Must be run from Kvasir-structured directory
export PYTHONPATH=$PYTHONPATH:$(pwd)

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"
CKPT="results/unet_run/best.pt"

if [ ! -f "$CKPT" ]; then
    echo "Checkpoint not found: $CKPT"
    exit 1
fi

python3 -m postprocess.evaluate \
    --model unet \
    --ckpt "$CKPT" \
    --data-dir "$DATA_DIR" \
    --benchmark
