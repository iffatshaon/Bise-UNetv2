import os
import shutil
import glob
import numpy as np
from pathlib import Path
from tqdm import tqdm
from PIL import Image, ImageDraw

# Config
KVASIR_PATH = "/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"
LDPOLYP_PATH = "/media/iffat/DataDrive/dataset/LDPolyp"
TARGET_PATH = "/media/iffat/DataDrive/dataset/CombinedDataset"

# LDPolyp Logic (using PIL)
def parse_mask_from_txt(txt_path, shape):
    # shape: (h, w)
    h, w = shape
    mask = Image.new("L", (w, h), 0)
    draw = ImageDraw.Draw(mask)
    
    if not os.path.exists(txt_path): return mask
    try:
        with open(txt_path, 'r') as f: lines = f.readlines()
        if not lines: return mask
        # First line check
        first = lines[0].strip()
        if not first: return mask
        
        for line in lines:
            parts = list(map(int, line.strip().split()))
            if len(parts) == 1: continue 
            if len(parts) >= 4:
                x1, y1, x2, y2 = parts[:4]
                draw.rectangle([x1, y1, x2, y2], fill=255)
    except Exception as e:
        print(f"Error parsing {txt_path}: {e}")
    return mask

def setup_dirs():
    if os.path.exists(TARGET_PATH):
        print(f"Removing existing target: {TARGET_PATH}")
        shutil.rmtree(TARGET_PATH)
    
    os.makedirs(os.path.join(TARGET_PATH, "images"), exist_ok=True)
    os.makedirs(os.path.join(TARGET_PATH, "masks"), exist_ok=True)
    print(f"Created {TARGET_PATH}")

def process_kvasir():
    print("Processing Kvasir-SEG...")
    img_dir = os.path.join(KVASIR_PATH, "images")
    msk_dir = os.path.join(KVASIR_PATH, "masks")
    
    images = sorted(glob.glob(os.path.join(img_dir, "*.jpg")))
    
    for img_p in tqdm(images):
        name = Path(img_p).stem
        msk_p = os.path.join(msk_dir, name + ".jpg")
        
        if not os.path.exists(msk_p):
            # Try png?
            msk_p = os.path.join(msk_dir, name + ".png")
            if not os.path.exists(msk_p):
                continue
                
        # Copy with prefix
        new_name = f"kvasir_{name}.jpg"
        
        # Copy image
        shutil.copy2(img_p, os.path.join(TARGET_PATH, "images", new_name))
        
        # Copy mask (ensure jpg extension consistency if needed, but copy2 preserves ext)
        # We rename mask to match image filename base
        shutil.copy2(msk_p, os.path.join(TARGET_PATH, "masks", new_name))

def process_ldpolyp():
    print("Processing LDPolyp...")
    for split in ["trainValid", "Test"]:
        split_root = os.path.join(LDPOLYP_PATH, split)
        img_root = os.path.join(split_root, "Images")
        ann_root = os.path.join(split_root, "Annotations")
        
        if not os.path.exists(img_root): continue
        
        vid_folders = os.listdir(img_root)
        for vid in tqdm(vid_folders, desc=f"LDPolyp {split}"):
            vid_img_path = os.path.join(img_root, vid)
            vid_ann_path = os.path.join(ann_root, vid)
            
            if not os.path.isdir(vid_img_path): continue
            
            images = sorted(glob.glob(os.path.join(vid_img_path, "*.jpg")))
            for img_p in images:
                name = Path(img_p).stem
                txt_p = os.path.join(vid_ann_path, name + ".txt")
                
                # Check annotations
                if not os.path.exists(txt_p): continue
                
                # Read Image to get shape
                try:
                    with Image.open(img_p) as img:
                        w, h = img.size
                except Exception:
                    continue
                
                # Generate Mask
                mask = parse_mask_from_txt(txt_p, (h, w))
                
                new_name = f"ldpolyp_{split}_{vid}_{name}.jpg"
                
                # Save Image
                shutil.copy2(img_p, os.path.join(TARGET_PATH, "images", new_name))
                
                # Save Mask
                mask.save(os.path.join(TARGET_PATH, "masks", new_name))

def main():
    setup_dirs()
    process_kvasir()
    process_ldpolyp()
    
    # Validation
    n_img = len(os.listdir(os.path.join(TARGET_PATH, "images")))
    n_msk = len(os.listdir(os.path.join(TARGET_PATH, "masks")))
    print(f"\nFinal Counts:\nImages: {n_img}\nMasks: {n_msk}")

if __name__ == "__main__":
    main()
