import os

models = [
    "bisenet",
    "biseunetv1",
    "biseunetv2",
    "biseunetv3",
    "biseunetv4",
    "biseunetv5",
    "biseunetv6",
    "biseunetv7",
    "ducknet",
    "hardnet",
    "hardunet",
    "unet"
]

template = """#!/bin/bash
source ../.venv/bin/activate
# Must be run from Kvasir-structured directory
export PYTHONPATH=$PYTHONPATH:$(pwd)

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"
CKPT="results/{model}_run/best.pt"

if [ ! -f "$CKPT" ]; then
    echo "Checkpoint not found: $CKPT"
    exit 1
fi

python3 -m postprocess.evaluate \\
    --model {model} \\
    --ckpt "$CKPT" \\
    --data-dir "$DATA_DIR" \\
    --benchmark
"""

os.makedirs("scripts", exist_ok=True)

for m in models:
    filename = f"scripts/run_eval_{m}.sh"
    content = template.format(model=m)
    with open(filename, "w") as f:
        f.write(content)
    print(f"Created {filename}")
    os.chmod(filename, 0o755)
