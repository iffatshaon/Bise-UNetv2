import os

target_dir = "/media/iffat/DataDrive/dataset/LDPolyp"

if not os.path.exists(target_dir):
    print(f"Directory not found: {target_dir}")
else:
    print(f"Contents of {target_dir}:")
    try:
        items = os.listdir(target_dir)
        for item in items:
            print(f" - {item}")
            sub_path = os.path.join(target_dir, item)
            if os.path.isdir(sub_path):
                sub_items = os.listdir(sub_path)[:5]
                print(f"   Sample contents of {item}: {sub_items}")
    except PermissionError:
        print("Permission denied.")
