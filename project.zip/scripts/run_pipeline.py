import os
import subprocess
import glob
import sys
import time

# Configuration
SCRIPTS_DIR = "scripts"
RESULTS_DIR = "results"
# We assume the generic script handles environment setup, or we rely on the subshell inheriting it if we sourced it, 
# but calling 'bash scripts/...' executes in a fresh bash process. 
# The generic script sources the venv itself.

def get_model_name_from_script(script_path):
    """
    Extracts 'biseunetv1' from 'scripts/run_train_biseunetv1.sh'
    """
    basename = os.path.basename(script_path)
    # remove run_train_ prefix and .sh suffix
    if basename.startswith("run_train_") and basename.endswith(".sh"):
        return basename[10:-3]
    return None

def run_command(command, log_file=None):
    """
    Runs a shell command. Returns True if success, False otherwise.
    """
    if log_file:
        mode = "a" if os.path.exists(log_file) else "w"
        out_f = open(log_file, mode)
    else:
        out_f = None

    print(f"  > Executing: {command}")
    try:
        process = subprocess.Popen(
            command, 
            shell=True, 
            cwd=os.getcwd(), # Run from project root
            stdout=subprocess.PIPE if not log_file else out_f,
            stderr=subprocess.STDOUT if not log_file else out_f
        )
        
        # If not logging to file, stream to stdout
        if not log_file:
            while True:
                line = process.stdout.readline()
                if not line and process.poll() is not None:
                    break
                if line:
                    print(line.decode().strip())
        
        process.wait()
        return process.returncode == 0
    except Exception as e:
        print(f"  ! Error executing command: {e}")
        return False
    finally:
        if out_f:
            out_f.close()

def main():
    # 1. Identify all training scripts
    train_scripts = sorted(glob.glob(os.path.join(SCRIPTS_DIR, "run_train_*.sh")))
    
    if not train_scripts:
        print("No training scripts found!")
        sys.exit(1)

    print(f"Found {len(train_scripts)} training scripts.")
    
    # Ensure logs dir exists
    os.makedirs("logs", exist_ok=True)
    
    report = {
        "success": [],
        "failed_train": [],
        "failed_eval": [],
        "skipped_eval": []
    }
    
    start_time_global = time.time()

    for train_script in train_scripts:
        model_name = get_model_name_from_script(train_script)
        if not model_name:
            continue
            
        print(f"\n{'='*60}")
        print(f"Processing Model: {model_name}")
        print(f"{'='*60}")
        
        # 2. Run Training
        print(f"Step 1: Training ({train_script})...")
        # train_log = f"logs/train_{model_name}.log" # Optional: logging to file
        
        train_cmd = f"bash {train_script}"
        
        if run_command(train_cmd):
            print("  [SUCCESS] Training completed.")
            
            # 3. Run Evaluation (Only if train success) using generic script
            print(f"Step 2: Evaluation (scripts/run_eval_generic.sh {model_name})...")
            # eval_log = f"logs/eval_{model_name}.log"
            
            # Use the generic script
            eval_cmd = f"bash scripts/run_eval_generic.sh {model_name}"
            
            if run_command(eval_cmd):
                print("  [SUCCESS] Evaluation completed.")
                report["success"].append(model_name)
            else:
                print("  [FAILURE] Evaluation failed.")
                report["failed_eval"].append(model_name)
        else:
            print("  [FAILURE] Training failed. Skipping evaluation.")
            report["failed_train"].append(model_name)
            report["skipped_eval"].append(model_name)
            
    # 4. Final Report
    end_time_global = time.time()
    duration = (end_time_global - start_time_global) / 60
    
    print(f"\n{'#'*60}")
    print("FINAL REPORT")
    print(f"Total Duration: {duration:.1f} minutes")
    print(f"{'#'*60}")
    
    if report["success"]:
        print("\nCompleted Successfully:")
        for m in report["success"]:
            print(f"  - {m}")
            
    if report["failed_train"]:
        print("\nFailed during Training:")
        for m in report["failed_train"]:
            print(f"  - {m}")

    if report["failed_eval"]:
        print("\nFailed during Evaluation:")
        for m in report["failed_eval"]:
            print(f"  - {m}")
            
    if not report["failed_train"] and not report["failed_eval"]:
        print("\nAll experiments finished successfully!")
        sys.exit(0)
    else:
        sys.exit(1)

if __name__ == "__main__":
    main()
