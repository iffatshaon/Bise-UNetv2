#!/bin/bash
source ../.venv/bin/activate
# Must be run from Kvasir-structured directory
export PYTHONPATH=$PYTHONPATH:$(pwd)

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"

python3 -m train.train \
    --model biseunetv6 \
    --data-dir "$DATA_DIR" \
    --out-dir results/biseunetv6_run \
    --epochs 200 \
    --batch 8 \
    --mixed \
    --patience 15
