#!/bin/bash
# Ablation study evaluation script
# Evaluates BiseUNet V1 through V7 if checkpoints exist

export PYTHONPATH=$PYTHONPATH:$(pwd)
source ../.venv/bin/activate

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"
RESULTS_BASE="results"

echo "=== Starting Ablation Evaluation ==="

for v in {1..7}; do
    MODEL="biseunetv${v}"
    CKPT="${RESULTS_BASE}/${MODEL}_run/best.pt"
    
    echo "------------------------------------------------"
    if [ -f "$CKPT" ]; then
        echo "Evaluating ${MODEL}..."
        python3 -m postprocess.evaluate \
            --model "$MODEL" \
            --ckpt "$CKPT" \
            --data-dir "$DATA_DIR" \
            --benchmark
    else
        echo "Checkpoint for ${MODEL} not found at ${CKPT}. Skipping."
    fi
done

echo "=== Ablation Evaluation Finished ==="
