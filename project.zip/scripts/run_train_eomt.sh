#!/bin/bash
# Training script for EoMT on combined dataset
# Usage: bash scripts/run_train_eomt.sh

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ROOT="$(dirname "$DIR")"
source "$ROOT/.venv/bin/activate"
export PYTHONPATH="$PYTHONPATH:$ROOT"

DATA_DIR="/media/iffat/DataDrive/dataset/CombinedDataset"
OUT_DIR="$ROOT/results/combined/eomt_run"

echo "=== Training EoMT on Combined Dataset ==="
echo "Data: $DATA_DIR"
echo "Output: $OUT_DIR"

python3 -m train.train_combined \
    --model eomt \
    --data-dir "$DATA_DIR" \
    --out-dir "$OUT_DIR" \
    --epochs 200 \
    --batch 8 \
    --lr 1e-4 \
    --patience 15 \
    --img-size 256 \
    --mixed \
    --workers 4
