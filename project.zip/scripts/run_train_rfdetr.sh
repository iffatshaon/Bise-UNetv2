#!/bin/bash
# Training script for RF-DETR on combined dataset
# Usage: bash scripts/run_train_rfdetr.sh

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ROOT="$(dirname "$DIR")"
source "$ROOT/.venv/bin/activate"
export PYTHONPATH="$PYTHONPATH:$ROOT"

DATA_DIR="/media/iffat/DataDrive/dataset/CombinedDataset"
OUT_DIR="$ROOT/results/combined/rfdetr_run"

echo "=== Training RF-DETR on Combined Dataset ==="
echo "Data: $DATA_DIR"
echo "Output: $OUT_DIR"

python3 -m train.train_combined \
    --model rfdetr \
    --data-dir "$DATA_DIR" \
    --out-dir "$OUT_DIR" \
    --epochs 200 \
    --batch 8 \
    --lr 1e-4 \
    --patience 15 \
    --img-size 256 \
    --mixed \
    --workers 4
