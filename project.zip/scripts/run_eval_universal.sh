#!/bin/bash
# Universal Evaluation Script
# Usage: ./run_eval_universal.sh --model <name> --dataset <path> --ckpt <path> [options]

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source $DIR/../../.venv/bin/activate
export PYTHONPATH=$PYTHONPATH:$DIR/..

# Defaults
MODULE="postprocess.evaluate"

while [[ "$#" -gt 0 ]]; do
    case $1 in
        --model) MODEL="$2"; shift ;;
        --dataset) DATA_DIR="$2"; shift ;;
        --ckpt) CKPT="$2"; shift ;;
        --out-dir) OUT_DIR="$2"; shift ;;
        --module) MODULE="$2"; shift ;;
        *) EXTRA_ARGS="$EXTRA_ARGS $1" ;;
    esac
    shift
done

if [ -z "$MODEL" ] || [ -z "$DATA_DIR" ] || [ -z "$CKPT" ]; then
    echo "Error: Missing required arguments."
    echo "Usage: $0 --model <name> --dataset <path> --ckpt <path> [--module <postprocess.evaluate>] ..."
    exit 1
fi

CMD="python3 -m $MODULE \
    --model $MODEL \
    --ckpt \"$CKPT\" \
    --data-dir \"$DATA_DIR\" \
    $EXTRA_ARGS"

if [ ! -z "$OUT_DIR" ]; then
    CMD="$CMD --out-dir \"$OUT_DIR\""
fi

echo "Executing: $CMD"
eval $CMD
