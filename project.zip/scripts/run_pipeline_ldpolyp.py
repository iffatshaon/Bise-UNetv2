import os
import subprocess
import time

MODELS = [
    "bisenet", 
    "biseunetv1", "biseunetv2", "biseunetv3", "biseunetv4", "biseunetv5", "biseunetv6", "biseunetv7",
    "ducknet", 
    "hardnet", "hardunet", 
    "unet"
]

DATA_DIR = "/media/iffat/DataDrive/dataset/LDPolyp"
RESULTS_ROOT = "results/ldpolyp"

def run_command(cmd):
    print(f"Current Dir: {os.getcwd()}")
    print(f"Executing: {cmd}")
    ret = subprocess.call(cmd, shell=True)
    return ret == 0

def main():
    print("Starting LDPolyp Pipeline...")
    os.makedirs(RESULTS_ROOT, exist_ok=True)
    
    for model in MODELS:
        print(f"\n{'='*50}")
        print(f"Processing {model}")
        print(f"{'='*50}")
        
        out_dir = os.path.join(RESULTS_ROOT, f"{model}_run")
        
        # 1. Train
        train_cmd = (
            f"python3 -m train.train_ldpolyp "
            f"--model {model} "
            f"--data-dir \"{DATA_DIR}\" "
            f"--out-dir \"{out_dir}\" "
            f"--epochs 200 "
            f"--batch 8 "
            f"--mixed "
            f"--patience 15"
        )
        
        if run_command(train_cmd):
            print("  Training Success.")
            
            # 2. Evaluate
            ckpt = os.path.join(out_dir, "best.pt")
            eval_cmd = (
                f"python3 -m postprocess.evaluate_ldpolyp "
                f"--model {model} "
                f"--ckpt \"{ckpt}\" "
                f"--data-dir \"{DATA_DIR}\" "
                f"--out-dir \"{out_dir}\""
            )
            
            if run_command(eval_cmd):
                print("  Evaluation Success.")
            else:
                print("  Evaluation Failed.")
        else:
            print("  Training Failed. Skipping Eval.")

if __name__ == "__main__":
    main()
