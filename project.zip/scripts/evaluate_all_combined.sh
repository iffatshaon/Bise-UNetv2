#!/bin/bash
# scripts/evaluate_all_combined.sh

RESULTS_DIR="results/combined"
DATA_DIR="/media/iffat/DataDrive/dataset/CombinedDataset"

if [ -d "$RESULTS_DIR" ]; then
    for run_dir in "$RESULTS_DIR"/*_run; do
        if [ -d "$run_dir" ]; then
            MODEL_NAME=$(basename "$run_dir" | sed 's/_run//')
            CKPT="$run_dir/best.pt"
            
            if [ -f "$CKPT" ]; then
                echo "====================================================="
                echo "Evaluating model: $MODEL_NAME from $run_dir"
                echo "====================================================="
                .venv/bin/python -m postprocess.evaluate \
                    --model "$MODEL_NAME" \
                    --ckpt "$CKPT" \
                    --data-dir "$DATA_DIR"
            else
                echo "No best.pt found for $MODEL_NAME in $run_dir"
            fi
        fi
    done
else
    echo "Directory $RESULTS_DIR does not exist."
fi

echo "====================================================="
echo "All evaluations complete. Generating Latex Tables..."
echo "====================================================="
.venv/bin/python scripts/make_tables.py

