import os

datasets = {
    "kvasir": "/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG",
    "ldpolyp": "/media/iffat/DataDrive/dataset/LDPolyp"
}

for name, path in datasets.items():
    print(f"\n--- Inspecting {name} at {path} ---")
    if not os.path.exists(path):
        print(f"Directory not found: {path}")
        continue
        
    try:
        items = os.listdir(path)
        print(f"Root contents: {items}")
        for item in items:
            sub_path = os.path.join(path, item)
            if os.path.isdir(sub_path):
                sub_items = os.listdir(sub_path)[:5]
                print(f"  Folder '{item}' sample: {sub_items}")
                # check image extensions
    except Exception as e:
        print(f"Error: {e}")
