#!/bin/bash
export PYTHONPATH=$PYTHONPATH:$(pwd)
source ../.venv/bin/activate

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"

python3 -m train.train \
    --model hardnet \
    --data-dir "$DATA_DIR" \
    --out-dir results/hardnet_run \
    --epochs 200 \
    --batch 8 \
    --mixed \
    --patience 15
