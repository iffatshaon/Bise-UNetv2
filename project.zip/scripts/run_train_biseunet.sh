#!/bin/bash
# Generic script for BiSeUNet V1-V7
# Usage: ./run_train_biseunet.sh [version] [extra_args]
# Example: ./run_train_biseunet.sh v7 --batch 16

VERSION=${1:-v7} # Default to v7
shift

MODEL="biseunet${VERSION}"
DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"

echo "Starting training for $MODEL..."

export PYTHONPATH=$PYTHONPATH:$(pwd)
source ../.venv/bin/activate

python3 -m train.train \
    --model "$MODEL" \
    --data-dir "$DATA_DIR" \
    --out-dir "results/${MODEL}_run" \
    --epochs 200 \
    --batch 8 \
    --mixed \
    --patience 15 \
    "$@"
