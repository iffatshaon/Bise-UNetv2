#!/bin/bash
# Script to sequentially train and evaluate all 10 BiSeUNetV7 ablation models 
# on the combined dataset.

echo "Starting training and evaluation for all 10 ablation models..."

.venv/bin/python scripts/run_pipeline_universal.py \
    --dataset combined \
    --models \
        biseunetv7_ablation_no_skips \
        biseunetv7_ablation_arm_sp \
        biseunetv7_ablation_ffm_early \
        bisenet_dsconv \
        biseunetv7_ablation_no_sp \
        biseunetv7_ablation_no_eca \
        biseunetv7_ablation_no_ghost \
        biseunetv7_ablation_no_ffm_light \
        biseunetv7_ablation_aspp \
        biseunetv7_ablation_sp_skips \
    --epochs 200 \
    --batch 8 \
    --results-dir "results/ablation"

echo "Finished all ablation models."
