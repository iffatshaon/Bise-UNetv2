#!/bin/bash
source ../.venv/bin/activate
# Must be run from Kvasir-structured directory
export PYTHONPATH=$PYTHONPATH:$(pwd)

DATA_DIR="/media/iffat/DataDrive/dataset/kvasir-seg/Kvasir-SEG"

python3 -m train.train \
    --model unet \
    --data-dir "$DATA_DIR" \
    --out-dir results/unet_run \
    --epochs 100 \
    --batch 8 \
    --mixed \
    --lr 1e-3
