import os
import glob
import matplotlib.pyplot as plt
import numpy as np

def get_metrics(filepath):
    fps = None
    dice = None
    in_test = False
    model_name = os.path.basename(os.path.dirname(filepath)).replace('_run', '')
    
    try:
        with open(filepath, 'r') as f:
            lines = f.readlines()
            for line in lines:
                if 'FPS (Inference Speed):' in line:
                    fps = float(line.split(':')[1].strip())
                elif 'Test Set Evaluation' in line:
                    in_test = True
                
                # We want Test Dice
                if in_test and 'Dice        :' in line:
                    dice = float(line.split(':')[1].strip())
                    in_test = False # stop looking after we find Test Dice
                    
        return model_name, fps, dice
    except Exception as e:
        print(f"Error reading {filepath}: {e}")
        return model_name, None, None

def main():
    ablation_dirs = glob.glob('/media/iffat/DataDrive/Projects/Kvasir-structured/results/ablation/*_run/results.txt')
    baseline_dir = '/media/iffat/DataDrive/Projects/Kvasir-structured/results/combined/biseunetv7_run/results.txt'
    
    all_files = list(ablation_dirs)
    if os.path.exists(baseline_dir):
        all_files.append(baseline_dir)
        
    data = []
    
    for f in all_files:
        name, fps, dice = get_metrics(f)
        if fps is not None and dice is not None:
            data.append((name, dice, fps))
            print(f"Loaded {name}: Dice={dice:.4f}, FPS={fps:.1f}")
            
    if not data:
        print("No data found!")
        return

    # Sort by Dice for a logical curve progression
    data.sort(key=lambda x: x[1])
    
    names = [x[0] for x in data]
    dices = [x[1] for x in data]
    fpss = [x[2] for x in data]
    
    # Create plot with white background
    fig, ax = plt.subplots(figsize=(10, 7))
    fig.patch.set_facecolor('white')
    ax.set_facecolor('white')
    
    # Scatter plot
    ax.scatter(dices, fpss, color='royalblue', zorder=3, s=60, edgecolors='black', linewidths=0.5)
    
    # Annotate points
    for name, d, f in data:
        display_name = name.replace('biseunetv7_ablation_', '').replace('biseunetv7', 'Baseline')
        # Avoid overlapping annotations slightly
        ax.annotate(display_name, (d, f), textcoords="offset points", xytext=(5, 5), ha='left', fontsize=9,
                    bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="gray", alpha=0.7))
        
    # Draw a line curve connecting the points (to satisfy "draw a curve on each of the points")
    from scipy.interpolate import interp1d
    try:
        # Interpolate a smooth curve if possible
        if len(dices) > 3:
            f_interp = interp1d(dices, fpss, kind='quadratic')
            x_line = np.linspace(min(dices), max(dices), 200)
            y_line = f_interp(x_line)
            ax.plot(x_line, y_line, 'r--', alpha=0.5, zorder=2, label='Trade-off Trend Curve')
        else:
            ax.plot(dices, fpss, 'r--', alpha=0.5, zorder=2, label='Trade-off Curve')
    except Exception as e:
        # Fallback to simple connection
        ax.plot(dices, fpss, 'r--', alpha=0.5, zorder=2, label='Trade-off Trend Curve')
    
    # Vertical line at BiSeUNetV7 baseline
    baseline_dice = None
    baseline_fps = None
    for name, d, f in data:
        if name == 'biseunetv7':
            baseline_dice = d
            baseline_fps = f
            break
            
    if baseline_dice is not None:
        ax.axvline(x=baseline_dice, color='green', linestyle='-', alpha=0.6, linewidth=2, 
                   label=f'BiSeUNetV7 (Baseline) Dice={baseline_dice:.4f}', zorder=1)
        # Highlight baseline point
        ax.scatter([baseline_dice], [baseline_fps], color='green', s=120, edgecolors='black', zorder=4, marker='*')

    ax.set_xlabel('Test Dice Score', fontsize=12, fontweight='bold')
    ax.set_ylabel('Inference Speed (FPS)', fontsize=12, fontweight='bold')
    ax.set_title('Ablation Study: FPS vs. Dice Score', fontsize=14, fontweight='bold')
    ax.grid(True, linestyle=':', alpha=0.6, color='gray')
    ax.legend(loc='lower left')
    
    plt.tight_layout()
    out_path = '/media/iffat/DataDrive/Projects/Kvasir-structured/results/ablation_fps_vs_dice.png'
    plt.savefig(out_path, dpi=300, facecolor='white', bbox_inches='tight')
    print(f"Plot saved to {out_path}")

if __name__ == '__main__':
    main()
