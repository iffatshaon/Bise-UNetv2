import os
import glob
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from pathlib import Path
from .dataset_prep import set_seed, normalize_image, resize_pair, simple_augs

def list_ldpolyp_pairs(root_dir, subset="trainValid"):
    # subset: 'trainValid' or 'Test'
    img_root = os.path.join(root_dir, subset, "Images")
    ann_root = os.path.join(root_dir, subset, "Annotations")
    
    pairs = []
    if not os.path.exists(img_root):
        print(f"Warning: {img_root} does not exist")
        return pairs
        
    # Structure: subset/Images/video_id/frame.jpg
    vid_folders = os.listdir(img_root)
    for vid in vid_folders:
        vid_img_path = os.path.join(img_root, vid)
        vid_ann_path = os.path.join(ann_root, vid)
        
        if not os.path.isdir(vid_img_path): continue
        
        images = sorted(glob.glob(os.path.join(vid_img_path, "*.jpg")))
        for img_p in images:
            name = Path(img_p).stem
            txt_p = os.path.join(vid_ann_path, name + ".txt")
            if os.path.exists(txt_p):
                pairs.append((img_p, txt_p))
    return pairs

def parse_mask_from_txt(txt_path, shape):
    # shape: (H, W)
    mask = np.zeros(shape, dtype=np.uint8)
    if not os.path.exists(txt_path):
        return mask
        
    with open(txt_path, 'r') as f:
        lines = f.readlines()
    
    if not lines:
        return mask
        
    try:
        # First line might be count
        first = lines[0].strip()
        if not first: return mask
        
        count = int(first)
        if count == 0:
            return mask
            
        for line in lines[1:]:
            parts = list(map(int, line.strip().split()))
            if len(parts) >= 4:
                # Assuming x1 y1 x2 y2
                x1, y1, x2, y2 = parts[:4]
                cv2.rectangle(mask, (x1, y1), (x2, y2), 255, -1)
    except ValueError:
        pass
        
    return mask

class LDPolypDS(Dataset):
    def __init__(self, pairs, C, train=True):
        self.pairs, self.C, self.train = pairs, C, train
        
    def __len__(self): return len(self.pairs)
    
    def __getitem__(self, i):
        ip, tp = self.pairs[i]
        img_bgr = cv2.imread(ip, cv2.IMREAD_COLOR)
        if img_bgr is None:
            # Fallback for error reading
            print(f"Error reading image: {ip}")
            img_bgr = np.zeros((256, 256, 3), dtype=np.uint8)
            
        h, w = img_bgr.shape[:2]
        
        msk_gray = parse_mask_from_txt(tp, (h, w))
        
        img_bgr, msk_gray = resize_pair(img_bgr, msk_gray, self.C["IMG_SIZE"])
        
        if self.train:
             img_bgr, msk_gray = simple_augs(img_bgr, msk_gray, self.C)
             
        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB).astype(np.float32)/255.0
        img = normalize_image(img_rgb)
        msk = (msk_gray > 127).astype(np.float32)[None, ...] # Binary 0/1 float
        return torch.from_numpy(img), torch.from_numpy(msk)

def get_ldpolyp_loaders(root_dir, C, seed=42):
    all_train = list_ldpolyp_pairs(root_dir, "trainValid")
    test_pairs = list_ldpolyp_pairs(root_dir, "Test")
    
    if not all_train:
        print("No training pairs found! check path structure.")
    
    # Random split 80/20 for Train/Val
    n = len(all_train)
    rng = np.random.default_rng(seed)
    idx = np.arange(n)
    rng.shuffle(idx)
    split = int(n * 0.8)
    
    tr_pairs = [all_train[i] for i in idx[:split]]
    va_pairs = [all_train[i] for i in idx[split:]]
    
    print(f"LDPolyp Split: Train={len(tr_pairs)}, Val={len(va_pairs)}, Test={len(test_pairs)}")
    
    train_loader = DataLoader(
        LDPolypDS(tr_pairs, C, train=True),
        batch_size=C["BATCH"], shuffle=True,
        num_workers=4, pin_memory=True, persistent_workers=True
    )
    val_loader = DataLoader(
        LDPolypDS(va_pairs, C, train=False),
        batch_size=C["BATCH"], shuffle=False,
        num_workers=4, pin_memory=True, persistent_workers=True
    )
    test_loader = DataLoader(
        LDPolypDS(test_pairs, C, train=False),
        batch_size=C["BATCH"], shuffle=False,
        num_workers=4, pin_memory=True, persistent_workers=True
    )
    
    return train_loader, val_loader, test_loader
