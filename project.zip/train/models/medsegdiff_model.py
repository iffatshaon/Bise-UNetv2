# medsegdiff_model.py
# ------------------------------------------------------------
# MedSegDiff-style conditional DDPM for binary medical segmentation
# - Learns p_theta(eps | noisy_mask, timestep, image_condition)
# - Image conditioning via FiLM from a small CNN encoder
# - Frequency filtering (FF-Parser idea) on feature maps
# - Provides: model forward for ε-pred, diffusion helpers, DDIM sampler
# ------------------------------------------------------------

from typing import Tuple, Optional
import math, random
import torch
import torch.nn as nn
import torch.nn.functional as F


# ------------------------- utilities -------------------------
def timestep_embedding(t: torch.Tensor, dim: int) -> torch.Tensor:
    """Sinusoidal time embedding (NeRF/DDPM style)."""
    half = dim // 2
    freqs = torch.exp(-math.log(10000) * torch.arange(0, half, device=t.device).float() / half)
    args = t.float().unsqueeze(1) * freqs.unsqueeze(0)
    emb = torch.cat([torch.cos(args), torch.sin(args)], dim=1)
    if dim % 2 == 1:
        emb = F.pad(emb, (0,1))
    return emb  # [B, dim]


def lowpass_fft(x: torch.Tensor, keep_ratio: float = 0.5) -> torch.Tensor:
    """
    Low-pass filter via FFT, computed in float32 to avoid cuFFT half-precision limits.
    x: (B,C,H,W) any dtype (fp16/fp32) -> returns same dtype as input.
    """
    B, C, H, W = x.shape
    orig_dtype = x.dtype

    # compute FFT in float32
    x32 = x.to(torch.float32)

    fx = torch.fft.fft2(x32, dim=(-2, -1), norm="ortho")
    fx = torch.fft.fftshift(fx, dim=(-2, -1))

    # central box mask
    h_keep = max(1, int(H * keep_ratio / 2))
    w_keep = max(1, int(W * keep_ratio / 2))
    cy, cx = H // 2, W // 2
    mask = torch.zeros((H, W), device=x.device, dtype=torch.bool)
    mask[cy - h_keep : cy + h_keep, cx - w_keep : cx + w_keep] = True
    mask = mask.view(1, 1, H, W).expand(B, C, H, W)

    fx = torch.where(mask, fx, torch.zeros_like(fx))

    fx = torch.fft.ifftshift(fx, dim=(-2, -1))
    y32 = torch.fft.ifft2(fx, dim=(-2, -1), norm="ortho").real

    return y32.to(orig_dtype)


# -------------------- image conditioner ----------------------
class ImgCond(nn.Module):
    """
    Lightweight image encoder -> FiLM (scale, shift) at multiple resolutions.
    Input: RGB (B,3,H,W) normalized (same as your pipeline).
    """
    def __init__(self, in_ch=3, base=32):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv2d(in_ch, base, 3, 1, 1), nn.GroupNorm(8, base), nn.SiLU(),
            nn.Conv2d(base, base, 3, 1, 1), nn.GroupNorm(8, base), nn.SiLU(),
        )
        self.down1 = nn.Sequential(
            nn.Conv2d(base, base*2, 3, 2, 1), nn.GroupNorm(16, base*2), nn.SiLU(),
            nn.Conv2d(base*2, base*2, 3, 1, 1), nn.GroupNorm(16, base*2), nn.SiLU(),
        )
        self.down2 = nn.Sequential(
            nn.Conv2d(base*2, base*4, 3, 2, 1), nn.GroupNorm(32, base*4), nn.SiLU(),
            nn.Conv2d(base*4, base*4, 3, 1, 1), nn.GroupNorm(32, base*4), nn.SiLU(),
        )
        # project FiLM params per scale
        self.to_film16 = nn.Conv2d(base*2, base*2*2, 1)  # (scale, shift)
        self.to_film32 = nn.Conv2d(base*4, base*4*2, 1)

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        s8 = self.stem(x)                 # (B, base, H, W)
        s16 = self.down1(s8)              # (B, 2b, H/2, W/2)
        s32 = self.down2(s16)             # (B, 4b, H/4, W/4)
        # FiLM parameters
        film16 = self.to_film16(s16)      # (B, 4b, H/2, W/2) -> split into (scale, shift)
        film32 = self.to_film32(s32)      # (B, 8b, H/4, W/4)
        return s8, film16, film32


# ---------------------- diffusion UNet -----------------------
class ResBlock(nn.Module):
    def __init__(self, c_in, c_out, t_dim, use_film=False):
        super().__init__()
        self.use_film = use_film
        self.norm1 = nn.GroupNorm(8, c_in)
        self.act = nn.SiLU()
        self.conv1 = nn.Conv2d(c_in, c_out, 3, 1, 1)
        self.norm2 = nn.GroupNorm(8, c_out)
        self.conv2 = nn.Conv2d(c_out, c_out, 3, 1, 1)
        self.time = nn.Linear(t_dim, c_out)
        self.short = nn.Conv2d(c_in, c_out, 1) if c_in != c_out else nn.Identity()

    def forward(self, x, t_emb, film=None):
        h = self.conv1(self.act(self.norm1(x)))
        h = h + self.time(t_emb).unsqueeze(-1).unsqueeze(-1)

        if self.use_film and film is not None:
            if film.shape[-2:] != h.shape[-2:]:
                film = F.interpolate(film, size=h.shape[-2:], mode="bilinear", align_corners=False)
            scale, shift = film.chunk(2, dim=1)   # expects film C == 2*c_out
            # OPTIONAL: sanity check (will throw early if still mismatched)
            if scale.shape[1] != h.shape[1] or shift.shape[1] != h.shape[1]:
                raise RuntimeError(
                    f"FiLM channel mismatch: expected {2*h.shape[1]} but got {film.shape[1]}"
                )
            h = h * (1 + torch.tanh(scale)) + shift

        h = self.conv2(self.act(self.norm2(h)))
        return h + self.short(x)


class Down(nn.Module):
    def __init__(self, c_in, c_out, t_dim, use_film=False):
        super().__init__()
        self.res1 = ResBlock(c_in, c_out, t_dim, use_film)
        self.res2 = ResBlock(c_out, c_out, t_dim, use_film)
        self.pool = nn.Conv2d(c_out, c_out, 3, 2, 1)

    def forward(self, x, t_emb, film=None):
        x = self.res1(x, t_emb, film)
        x = self.res2(x, t_emb, film)
        skip = x
        x = self.pool(x)
        return x, skip


class Up(nn.Module):
    def __init__(self, c_in, c_out, t_dim, use_film=False):
        super().__init__()
        self.res1 = ResBlock(c_in, c_out, t_dim, use_film)
        self.res2 = ResBlock(c_out, c_out, t_dim, use_film)

    def forward(self, x, skip, t_emb, film=None):
        x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        x = torch.cat([x, skip], dim=1)
        x = self.res1(x, t_emb, film)
        x = self.res2(x, t_emb, film)
        return x


# --- in medsegdiff_model.py ---

class CondUNet(nn.Module):
    """
    Noise predictor ε_theta(noisy_mask | t, image).
    base: model width (try 48 first; 64 is heavier)
    img_base: conditioner width; keep img_base = base//2 so Up-path FiLM matches.
    use_fft: True uses lowpass_fft; False uses cheap depthwise blurs (less memory)
    checkpoint: True enables gradient checkpointing on heavy blocks (big mem win)
    """
    def __init__(self, base=48, t_dim=256, img_base=None, use_fft=False, checkpoint=False):
        super().__init__()
        if img_base is None:
            img_base = base // 2  # keeps Up-path FiLM channels aligned
        self.base = base
        self.use_fft = use_fft
        self.checkpoint = checkpoint

        self.in_conv = nn.Conv2d(1, base, 3, 1, 1)
        self.t_dim = t_dim
        self.time_mlp = nn.Sequential(nn.Linear(t_dim, t_dim), nn.SiLU(), nn.Linear(t_dim, t_dim))

        # Down channels
        c1 = base*2       # after down1
        c2 = base*4       # after down2

        self.down1 = Down(base, c1, t_dim, use_film=True)   # H -> H/2
        self.down2 = Down(c1,   c2, t_dim, use_film=True)   # H/2 -> H/4
        self.mid   = ResBlock(c2, c2, t_dim, use_film=False)

        self.up2 = Up(c2 + c2, c1, t_dim, use_film=True)    # H/4 -> H/2
        self.up1 = Up(c1 + c1, base, t_dim, use_film=True)  # H/2 -> H

        self.out = nn.Sequential(nn.GroupNorm(8, base), nn.SiLU(), nn.Conv2d(base, 1, 3, 1, 1))

        # ---- Image conditioner ----
        self.imgcond = ImgCond(in_ch=3, base=img_base)  # gives film16: 4*img_base, film32: 8*img_base

        # ---- FiLM projectors for DOWN path (sizes derived from base) ----
        in16 = 4 * img_base            # film16 channels
        in32 = 8 * img_base            # film32 channels
        need16 = 2 * c1                # Down1 needs 2*c_out
        need32 = 2 * c2                # Down2 needs 2*c_out
        self.fproj16_down = nn.Conv2d(in16, need16, 1, bias=True)
        self.fproj32_down = nn.Conv2d(in32, need32, 1, bias=True)

        # ---- Low-pass: FFT or depthwise blur (choose by flag) ----
        if self.use_fft:
            self.lp = lambda f: lowpass_fft(f, keep_ratio=0.5)
        else:
            k = 5
            self.blur1 = nn.Conv2d(c1, c1, k, 1, k//2, groups=c1, bias=False)
            self.blur2 = nn.Conv2d(c2, c2, k, 1, k//2, groups=c2, bias=False)
            nn.init.constant_(self.blur1.weight, 1.0/(k*k))
            nn.init.constant_(self.blur2.weight, 1.0/(k*k))

    def _maybe_ckpt(self, fn, *args):
        if not self.checkpoint or not self.training:
            return fn(*args)
        from torch.utils.checkpoint import checkpoint
        return checkpoint(fn, *args, use_reentrant=False)

    def forward(self, noisy_mask: torch.Tensor, t: torch.Tensor, image_rgb: torch.Tensor) -> torch.Tensor:
    # time embedding
        t_emb = timestep_embedding(t, self.t_dim)
        t_emb = self.time_mlp(t_emb)

        # image conditioning (produces FiLM tensors at 1/2 and 1/4 res)
        s8, film16, film32 = self.imgcond(image_rgb)  # film16: 4*img_base, film32: 8*img_base

        # project FiLM for DOWN path so channels match 2*c_out at each scale
        film16_d = self.fproj16_down(film16)   # -> 2*(base*2) = 4*base
        film32_d = self.fproj32_down(film32)   # -> 2*(base*4) = 8*base

        # input conv
        x = self.in_conv(noisy_mask)           # (B, base, H, W)

        # ---- DOWN 1 (H -> H/2) ----
        x, skip1 = self.down1(x, t_emb, film16_d)
        if self.use_fft:
            x = self.lp(x)
        else:
            x = self.blur1(x)

        # ---- DOWN 2 (H/2 -> H/4) ----
        x, skip2 = self.down2(x, t_emb, film32_d)
        if self.use_fft:
            x = self.lp(x)
        else:
            x = self.blur2(x)

        # ---- MID ----
        x = self.mid(x, t_emb)

        # ---- UP 2 (H/4 -> H/2) ----
        x = self.up2(x, skip2, t_emb, film32)

        # ---- UP 1 (H/2 -> H) ----
        x = self.up1(x, skip1, t_emb, film16)

        # output ε prediction
        return self.out(x)






# ------------------------ diffusion core ------------------------
class GaussianDiffusion(nn.Module):
    def __init__(self, model: CondUNet, T: int = 1000, beta_start=1e-4, beta_end=0.02):
        super().__init__()
        self.model = model
        self.T = T
        betas = torch.linspace(beta_start, beta_end, T)
        alphas = 1.0 - betas
        alphas_cumprod = torch.cumprod(alphas, dim=0)
        self.register_buffer("betas", betas)
        self.register_buffer("alphas_cumprod", alphas_cumprod)
        self.register_buffer("alphas_cumprod_prev", torch.cat([torch.tensor([1.0]), alphas_cumprod[:-1]]))

    def q_sample(self, x0: torch.Tensor, t: torch.Tensor, noise: Optional[torch.Tensor] = None):
        """
        Forward diffusion: x_t = sqrt(a_cumprod)*x0 + sqrt(1-a_cumprod)*noise
        """
        if noise is None:
            noise = torch.randn_like(x0)
        a_bar = self.alphas_cumprod[t].view(-1, 1, 1, 1)
        return torch.sqrt(a_bar) * x0 + torch.sqrt(1.0 - a_bar) * noise

    def p_losses(self, x0_mask01: torch.Tensor, image_rgb: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Training objective: predict ε from (x_t, t, image). 
        x0_mask01 in [0,1]; we center to [-1,1] for diffusion.
        """
        B = x0_mask01.size(0)
        # center masks to [-1,1]
        x0 = x0_mask01 * 2.0 - 1.0
        t = torch.randint(0, self.T, (B,), device=x0.device, dtype=torch.long)
        noise = torch.randn_like(x0)
        xt = self.q_sample(x0, t, noise)
        eps_pred = self.model(xt, t, image_rgb)
        loss = F.mse_loss(eps_pred, noise)
        return loss, t

    @torch.no_grad()
    def ddim_sample(self, image_rgb: torch.Tensor, steps: int = 50) -> torch.Tensor:
        """
        DDIM sampling (deterministic) from pure noise to x0 mask in [-1,1].
        Returns mask logits (before sigmoid) at full image resolution.
        """
        self.model.eval()
        B, _, H, W = image_rgb.shape
        device = image_rgb.device
        times = torch.linspace(0, self.T-1, steps, device=device).long().flip(0)  # T-1 ... 0
        x = torch.randn((B, 1, H, W), device=device)

        a_bar = self.alphas_cumprod
        for i, t in enumerate(times):
            t_batch = torch.full((B,), t.item(), device=device, dtype=torch.long)
            eps = self.model(x, t_batch, image_rgb)
            a_t = a_bar[t]
            x0 = (x - torch.sqrt(1 - a_t) * eps) / torch.sqrt(a_t)
            if i < steps - 1:
                t_next = times[i+1]
                a_next = a_bar[t_next]
                x = torch.sqrt(a_next) * x0 + torch.sqrt(1 - a_next) * eps  # deterministic DDIM
            else:
                x = x0

        # x in [-1,1] -> logits: use scaled values as logits
        return x  # (B,1,H,W), treat as mask logits; apply BCE/Dice outside


# ------------------------ factory ------------------------
# def build_medsegdiff(T: int = 1000) -> GaussianDiffusion:
#     model = CondUNet(base=64, t_dim=256)
#     return GaussianDiffusion(model, T=T, beta_start=1e-4, beta_end=2e-2)

def build_medsegdiff(T: int = 1000, base: int = 48, use_fft: bool = False, checkpoint: bool = False) -> GaussianDiffusion:
    model = CondUNet(base=base, t_dim=256, img_base=base//2, use_fft=use_fft, checkpoint=checkpoint)
    return GaussianDiffusion(model, T=T, beta_start=1e-4, beta_end=2e-2)