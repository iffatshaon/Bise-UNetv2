# bise_unet_spcp.py
from typing import List, Tuple, Optional
import torch
import torch.nn as nn
import torch.nn.functional as F

# ---------- Small building blocks ----------
def _conv_bn_relu(cin, cout, k=3, s=1, p=1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )

class DSConv(nn.Module):
    """Depthwise-separable conv used in the minimal v3 decoder."""
    def __init__(self, cin, cout, k=3, s=1, p=1):
        super().__init__()
        self.dw = nn.Conv2d(cin, cin, k, s, p, groups=cin, bias=False)
        self.dw_bn = nn.BatchNorm2d(cin)
        self.pw = nn.Conv2d(cin, cout, 1, bias=False)
        self.pw_bn = nn.BatchNorm2d(cout)
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        x = self.act(self.dw_bn(self.dw(x)))
        x = self.act(self.pw_bn(self.pw(x)))
        return x

# ---------- BiSeNet Spatial Path (ends at /8) ----------
class SpatialPath(nn.Module):
    """Shallow, high-res path: /2 → /4 → /8, then a 1×1 projection."""
    def __init__(self, in_ch=3, base=32):
        super().__init__()
        self.layer1 = _conv_bn_relu(in_ch, base, k=7, s=2, p=3)  # /2
        self.layer2 = _conv_bn_relu(base, base, k=3, s=2, p=1)   # /4
        self.layer3 = _conv_bn_relu(base, base, k=3, s=2, p=1)   # /8
        self.proj   = _conv_bn_relu(base, base, k=1, s=1, p=0)   # /8, C=base
        self.out_ch = base
    def forward(self, x):
        x = self.layer1(x); x = self.layer2(x); x = self.layer3(x)
        return self.proj(x)  # /8, C=base

# ---------- BiSeNet Context Path (provides UNet-style skips) ----------
class AttentionRefinement(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch, ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(ch),
            nn.ReLU(inplace=True),
        )
        self.att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(ch, ch, 1, bias=False),
            nn.BatchNorm2d(ch),
            nn.Sigmoid(),
        )
    def forward(self, x):
        feat = self.conv(x)
        return feat * self.att(feat)

class BasicBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.block = nn.Sequential(
            _conv_bn_relu(cin, cout, 3, stride, 1),
            _conv_bn_relu(cout, cout, 3, 1, 1),
        )
    def forward(self, x): return self.block(x)

class ContextPath(nn.Module):
    """
    Downsample to /32 with taps at /4, /8, /16(refined), /32 (BiSeNet-style).
    Channel plan (base=b): c4=b*2, c8=b*4, c16=b*4, c32=b*8.
    """
    def __init__(self, in_ch=3, base=32):
        super().__init__()
        b = base
        c2, c4, c8, c16, c32 = b, 2*b, 4*b, 4*b, 8*b
        self.s2  = BasicBlock(in_ch, c2,  stride=2)  # /2
        self.s4  = BasicBlock(c2,   c4,  stride=2)   # /4  (skip)
        self.s8  = BasicBlock(c4,   c8,  stride=2)   # /8  (skip)
        self.s16 = BasicBlock(c8,   c16, stride=2)   # /16
        self.s32 = BasicBlock(c16,  c32, stride=2)   # /32

        self.arm16 = AttentionRefinement(c16)
        self.arm32 = AttentionRefinement(c32)
        self.gp = nn.Sequential(  # global context on /32
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c32, c32, 1, bias=False),
            nn.BatchNorm2d(c32),
            nn.ReLU(inplace=True),
        )
        self.reduce32_to_16 = nn.Sequential(
            nn.Conv2d(c32, c16, 1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )
        self.post_merge_reduce = nn.Sequential(
            nn.Conv2d(c16, c16, 1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )

        self.skip_channels = (c4, c8, c16, c32)

    def forward(self, x):
        x2 = self.s2(x)
        x4 = self.s4(x2)
        x8 = self.s8(x4)
        x16 = self.s16(x8)
        x32 = self.s32(x16)

        x32_ref = self.arm32(x32) + self.gp(x32)
        x16_ref = self.arm16(x16)

        x32_red = self.reduce32_to_16(x32_ref)
        x32_up  = F.interpolate(x32_red, size=x16_ref.shape[-2:], mode="bilinear", align_corners=False)
        x16_ref = self.post_merge_reduce(x16_ref + x32_up)  # refined /16

        # Return UNet-style skips from CP
        return x4, x8, x16_ref, x32

# ---------- UNet decoder (minimal v3: DSConv per stage) ----------
class _UpLite(nn.Module):
    def __init__(self, cin, skip_ch, cout):
        super().__init__()
        self.fuse = DSConv(cin + skip_ch, cout, 3, 1, 1)
    def forward(self, x, skip):
        x = torch.cat([x, skip], dim=1)
        return self.fuse(x)

class UNetDecoderV3(nn.Module):
    def __init__(self, chs: Tuple[int,int,int,int], out_ch=1):
        super().__init__()
        c1_4, c1_8, c1_16, c1_32 = chs
        self.up1  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = _UpLite(c1_32, c1_16, c1_16)

        self.up2  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = _UpLite(c1_16, c1_8,  c1_8)

        self.up3  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = _UpLite(c1_8,  c1_4,  c1_4)

        self.up4  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.head = nn.Conv2d(c1_4, out_ch, 1)

    def forward(self, skips: List[torch.Tensor]):
        x1_4, x1_8, x1_16, x1_32 = skips

        y = self.up1(x1_32)     # /32 -> /16
        y = self.dec1(y, x1_16) # fuse /16

        y = self.up2(y)         # /16 -> /8
        y = self.dec2(y, x1_8)  # fuse /8

        y = self.up3(y)         # /8 -> /4
        y = self.dec3(y, x1_4)  # fuse /4

        y = self.up4(y)         # /4 -> /2
        logits = self.head(y)   # /2
        logits = F.interpolate(logits, scale_factor=2, mode="bilinear", align_corners=False)  # -> /1
        return logits

# ---------- Full model: CP for all skips, optional SP fused at /8 ----------
class BiseUNet(nn.Module):
    """
    Use CP to generate UNet skips at /4, /8, /16(refined), /32.
    Optionally inject SP(/8) into the /8 skip via concat + 1x1 projection (keeps decoder width fixed).
    """
    def __init__(self, in_ch=3, out_ch=1, base_ch=32, use_sp: bool = True):
        super().__init__()
        self.cp = ContextPath(in_ch=in_ch, base=base_ch)
        self.use_sp = use_sp
        if use_sp:
            self.sp = SpatialPath(in_ch=in_ch, base=base_ch)   # /8, C=base
            # Project [CP(/8) || SP(/8)] back to CP(/8) channels (c8 = 4*base)
            c8 = 4 * base_ch
            self.s8_proj = nn.Sequential(
                nn.Conv2d(c8 + self.sp.out_ch, c8, 1, bias=False),
                nn.BatchNorm2d(c8),
                nn.ReLU(inplace=True),
            )
        # Decoder expects the original CP skip widths
        self.decoder = UNetDecoderV3(self.cp.skip_channels, out_ch=out_ch)

    def forward(self, x):
        # CP skips
        x1_4, x1_8, x1_16r, x1_32 = self.cp(x)

        # Optional SP→/8 fusion
        if self.use_sp:
            sp8 = self.sp(x)  # /8, C=base
            # Up to /8 (already /8), concat with CP(/8), project back to c8
            x1_8 = self.s8_proj(torch.cat([x1_8, sp8], dim=1))

        return self.decoder([x1_4, x1_8, x1_16r, x1_32])

def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())

if __name__ == "__main__":
    net = BiseUNet(in_ch=3, out_ch=1, base=32, use_sp=True)
    x = torch.randn(1,3,256,256)
    y = net(x)
    print("out:", y.shape)
    print("params (M):", count_params(net)/1e6)
