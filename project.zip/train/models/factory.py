from .unet_model import UNet
from .bisenetv1 import BiSeNetV1
from .biseunetv1 import BiseUNetV1
from .biseunetv2 import BiseUNetV2
from .biseunetv3 import BiseUNetV3
from .biseunetv4 import BiseUNet as BiseUNetV4
from .biseunetv5 import BiseUNetV5
from .biseunetv6 import BiseUNetV6
from .biseunetv7 import BiseUNetV7
from .ducknet_model import DuckNet
from .hardnet_model import HardNetMSEG
from .hardUnet_model import HardUNet
from .odise_seg import ODISELite
from .medsegdiff_model import build_medsegdiff
from .bisenetformer_seg import BiSeNetFormerLite
from .rfdetr_seg import RFDetrSeg
from .eomt_seg import EoMTSeg

# Ablations
from .ablations.biseunetv7_ablation_no_skips import BiseUNetV7NoSkips
from .ablations.biseunetv7_ablation_arm_sp import BiseUNetV7AblationARM_SP
from .ablations.biseunetv7_ablation_ffm_early import BiseUNetV7AblationFFMEarly
from .ablations.bisenet_dsconv import BiSeNet_DSConv
from .ablations.biseunetv7_ablation_no_sp import BiseUNetV7AblationNoSP
from .ablations.biseunetv7_ablation_no_eca import BiseUNetV7AblationNoECA
from .ablations.biseunetv7_ablation_no_ghost import BiseUNetV7AblationNoGhost
from .ablations.biseunetv7_ablation_no_ffm_light import BiseUNetV7AblationNoFFMLight
from .ablations.biseunetv7_ablation_aspp import BiseUNetV7AblationASPP
from .ablations.biseunetv7_ablation_sp_skips import BiseUNetV7AblationSPSkips

def get_model(name, **kwargs):
    name = name.lower()
    in_ch = kwargs.get('in_ch', 3)
    out_ch = kwargs.get('out_ch', 1)
    base_ch = kwargs.get('base_ch', 32)
    
    if name == 'unet':
        return UNet(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
    
    elif name == 'bisenet':
        return BiSeNetV1(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
        
    elif name == 'biseunet' or name == 'biseunetv7':
        return BiseUNetV7(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch, 
                          use_sp=kwargs.get('use_sp', True),
                          use_ffm_light=kwargs.get('use_ffm_light', True))
    
    # BiSeUNet Variations
    elif name == 'biseunetv1':
        return BiseUNetV1(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
    elif name == 'biseunetv2':
        return BiseUNetV2(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
    elif name == 'biseunetv3':
        return BiseUNetV3(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
    elif name == 'biseunetv4':
        return BiseUNetV4(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
    elif name == 'biseunetv5':
        return BiseUNetV5(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
    elif name == 'biseunetv6':
        return BiseUNetV6(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
                          
    elif name == 'ducknet':
        return DuckNet(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
        
    elif name == 'hardnet':
        return HardNetMSEG(n_classes=out_ch)
        
    elif name == 'hardunet':
        return HardUNet(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
        
    elif name == 'odise':
        return ODISELite(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
        
    elif name == 'medsegdiff':
        # MedSegDiff is special (diffusion model)
        # It needs T steps.
        return build_medsegdiff(T=kwargs.get('t_steps', 1000), 
                                base=kwargs.get('base_ch', 48), 
                                use_fft=kwargs.get('use_fft', False), 
                                checkpoint=kwargs.get('checkpoint', False))

    elif name == 'bisenetformer':
        return BiSeNetFormerLite(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    elif name == 'rfdetr':
        return RFDetrSeg(
            in_ch=in_ch,
            out_ch=out_ch,
            d_model=kwargs.get('d_model', 128),
            num_enc_layers=kwargs.get('num_enc_layers', 4),
        )

    elif name == 'eomt':
        return EoMTSeg(
            in_ch=in_ch,
            out_ch=out_ch,
            d_model=kwargs.get('d_model', 128),
            n_tokens=kwargs.get('n_tokens', 4),
        )

    # --- Ablations Additions ---
    elif name == 'biseunetv7_ablation_no_skips':
        return BiseUNetV7NoSkips(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)
        
    elif name == 'biseunetv7_ablation_arm_sp':
        return BiseUNetV7AblationARM_SP(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    elif name == 'biseunetv7_ablation_ffm_early':
        # Disable ffm light specifically for this early model
        return BiseUNetV7AblationFFMEarly(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch, use_ffm_light=False)

    elif name == 'bisenet_dsconv':
        return BiSeNet_DSConv(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    elif name == 'biseunetv7_ablation_no_sp':
        return BiseUNetV7AblationNoSP(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    elif name == 'biseunetv7_ablation_no_eca':
        return BiseUNetV7AblationNoECA(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    elif name == 'biseunetv7_ablation_no_ghost':
        return BiseUNetV7AblationNoGhost(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    elif name == 'biseunetv7_ablation_no_ffm_light':
        return BiseUNetV7AblationNoFFMLight(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    elif name == 'biseunetv7_ablation_aspp':
        return BiseUNetV7AblationASPP(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    elif name == 'biseunetv7_ablation_sp_skips':
        return BiseUNetV7AblationSPSkips(in_ch=in_ch, out_ch=out_ch, base_ch=base_ch)

    else:
        raise ValueError(f"Unknown model architecture: {name}")
