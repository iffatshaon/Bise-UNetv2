# ============================================================
# File: bise_unetv1_minimal.py
# Minimal-change BiseUNet:
# - Keep the original BiSeNet-style encoder *unchanged*.
# - Replace ONLY each UNet decoder stage's "two 3x3 convs"
#   with ONE depthwise-separable conv (DSConv).
#
# Why this is minimal & beneficial:
# - Parameters ↓ (decoder is often ~30–45% of total params).
# - FLOPs ↓ while preserving feature widths & skip wiring.
# - Often *no loss* and can slightly improve Dice/IoU due to
#   reduced overfitting and better efficiency.
#
# Drop-in: training script from BiseUNet v1 still works.
# ============================================================
from typing import List
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---- BiSeNet encoder producing UNet-like skips (unchanged) ----
def _conv_bn_relu(cin, cout, k=3, s=1, p=1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )


class BasicBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.block = nn.Sequential(
            _conv_bn_relu(cin, cout, k=3, s=stride, p=1),
            _conv_bn_relu(cout, cout, k=3, s=1, p=1),
        )
    def forward(self, x): return self.block(x)


class AttentionRefinement(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch, ch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(ch),
            nn.ReLU(inplace=True),
        )
        self.att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(ch, ch, kernel_size=1, bias=False),
            nn.BatchNorm2d(ch),
            nn.Sigmoid(),
        )
    def forward(self, x):
        feat = self.conv(x)
        att = self.att(feat)
        return feat * att


class BiSeNetEncoderUNetSkips(nn.Module):
    """Unchanged BiSeNet-style context encoder yielding UNet skips [1/4, 1/8, 1/16(refined), 1/32]."""
    def __init__(self, in_ch: int = 3, base: int = 32):
        super().__init__()
        c2, c4, c8, c16, c32 = base, base*2, base*4, base*4, base*8
        self.s2  = BasicBlock(in_ch, c2,  stride=2)  # /2
        self.s4  = BasicBlock(c2,   c4,  stride=2)   # /4  (skip)
        self.s8  = BasicBlock(c4,   c8,  stride=2)   # /8  (skip)
        self.s16 = BasicBlock(c8,   c16, stride=2)   # /16
        self.s32 = BasicBlock(c16,  c32, stride=2)   # /32

        self.arm16 = AttentionRefinement(c16)
        self.arm32 = AttentionRefinement(c32)
        self.global_pool = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c32, c32, kernel_size=1, bias=False),
            nn.BatchNorm2d(c32),
            nn.ReLU(inplace=True),
        )
        self.reduce32_to_16 = nn.Sequential(
            nn.Conv2d(c32, c16, kernel_size=1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )
        self.post_merge_reduce = nn.Sequential(
            nn.Conv2d(c16, c16, kernel_size=1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )
        self.skip_channels = (c4, c8, c16, c32)

    def forward(self, x):
        x2  = self.s2(x)      # /2
        x4  = self.s4(x2)     # /4
        x8  = self.s8(x4)     # /8
        x16 = self.s16(x8)    # /16
        x32 = self.s32(x16)   # /32

        gp = self.global_pool(x32)
        x32_arm = self.arm32(x32) + gp
        x16_arm = self.arm16(x16)
        x32_red = self.reduce32_to_16(x32_arm)
        x32_up  = F.interpolate(x32_red, size=x16_arm.shape[-2:], mode="bilinear", align_corners=False)
        x16_ref = self.post_merge_reduce(x16_arm + x32_up)
        return [x4, x8, x16_ref, x32]


# ---- Minimal change: depthwise-separable fusion in decoder only ----
class DSConv(nn.Module):
    """Depthwise separable conv replacing 2x(3x3 conv) block in the decoder."""
    def __init__(self, cin, cout, k=3, s=1, p=1):
        super().__init__()
        self.dw = nn.Conv2d(cin, cin, kernel_size=k, stride=s, padding=p, groups=cin, bias=False)
        self.dw_bn = nn.BatchNorm2d(cin)
        self.pw = nn.Conv2d(cin, cout, kernel_size=1, bias=False)
        self.pw_bn = nn.BatchNorm2d(cout)
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        x = self.act(self.dw_bn(self.dw(x)))
        x = self.act(self.pw_bn(self.pw(x)))
        return x


class _UpBlockLite(nn.Module):
    """
    v1 decoder stage (before): concat -> Conv(3x3) -> BN+ReLU -> Conv(3x3) -> BN+ReLU
    minimal change (now):     concat -> DSConv(3x3 depthwise + 1x1 pointwise)
    """
    def __init__(self, cin: int, skip_ch: int, cout: int):
        super().__init__()
        self.fuse = DSConv(cin + skip_ch, cout, k=3, s=1, p=1)
    def forward(self, x, skip):
        x = torch.cat([x, skip], dim=1)
        return self.fuse(x)


class UNetDecoderLite(nn.Module):
    """
    UNet decoder but each stage uses a single DSConv instead of two 3x3 convs.
    Channel widths and upsampling schedule unchanged.
    """
    def __init__(self, chs: list, out_ch: int = 1):
        super().__init__()
        c1_4, c1_8, c1_16, c1_32 = chs

        self.up1  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = _UpBlockLite(c1_32, c1_16, c1_16)

        self.up2  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = _UpBlockLite(c1_16, c1_8,  c1_8)

        self.up3  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = _UpBlockLite(c1_8,  c1_4,  c1_4)

        self.up4  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.head = nn.Conv2d(c1_4, out_ch, kernel_size=1)

    def forward(self, skips: List[torch.Tensor]) -> torch.Tensor:
        x1_4, x1_8, x1_16, x1_32 = skips

        y = self.up1(x1_32)
        y = self.dec1(y, x1_16)

        y = self.up2(y)
        y = self.dec2(y, x1_8)

        y = self.up3(y)
        y = self.dec3(y, x1_4)

        y = self.up4(y)              # -> stride 1/2
        logits = self.head(y)        # -> stride 1/2
        logits = F.interpolate(logits, scale_factor=2, mode="bilinear", align_corners=False)  # -> stride 1
        return logits


def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


class BiseUNetV3(nn.Module):
    """
    Minimal-change BiseUNet: BiSeNet encoder (unchanged) + UNetDecoderLite.
    """
    def __init__(self, in_ch: int = 3, out_ch: int = 1, base_ch: int = 32):
        super().__init__()
        self.encoder = BiSeNetEncoderUNetSkips(in_ch=in_ch, base=base_ch)      # same as before
        self.decoder = UNetDecoderLite(list(self.encoder.skip_channels), out_ch=out_ch)  # lighter decoder

    def forward(self, x):
        skips = self.encoder(x)
        return self.decoder(skips)


if __name__ == "__main__":
    net = BiseUNetV3(in_ch=3, out_ch=1, base_ch=32)
    x = torch.randn(1,3,256,256)
    y = net(x)
    print("out:", y.shape)
    print("params (M):", count_params(net)/1e6)
