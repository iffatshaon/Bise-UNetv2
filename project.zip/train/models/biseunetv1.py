# ==============================================
# File: bise-unetv1.py
# Hybrid: BiSeNet-style encoder + UNet decoder
# Emits UNet-like skips from a BiSeNet context backbone.
# ==============================================
from typing import List, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F

# ---- BiSeNet components (lightweight, no FFM/head here) ----

def _conv_bn_relu(cin, cout, k=3, s=1, p=1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )


class BasicBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.block = nn.Sequential(
            _conv_bn_relu(cin, cout, k=3, s=stride, p=1),
            _conv_bn_relu(cout, cout, k=3, s=1, p=1),
        )
    def forward(self, x): return self.block(x)


class AttentionRefinement(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch, ch, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(ch),
            nn.ReLU(inplace=True),
        )
        self.att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(ch, ch, kernel_size=1, bias=False),
            nn.BatchNorm2d(ch),
            nn.Sigmoid(),
        )

    def forward(self, x):
        feat = self.conv(x)
        att = self.att(feat)
        return feat * att


class BiSeNetEncoderUNetSkips(nn.Module):
    """
    BiSeNet-like context path that produces UNet-style skip pyramid:
    returns features at strides [1/4, 1/8, 1/16(refined), 1/32].

    Channel plan with base (b):
        /4 : 2b
        /8 : 4b
        /16: 4b  (after ARMs + merge/refine)
        /32: 8b
    """
    def __init__(self, in_ch: int = 3, base: int = 32):
        super().__init__()
        # channels
        c2, c4, c8, c16, c32 = base, base*2, base*4, base*4, base*8

        # downsample chain to /32
        self.s2  = BasicBlock(in_ch, c2,  stride=2)  # /2
        self.s4  = BasicBlock(c2,   c4,  stride=2)   # /4  (skip 1)
        self.s8  = BasicBlock(c4,   c8,  stride=2)   # /8  (skip 2)
        self.s16 = BasicBlock(c8,   c16, stride=2)   # /16 (tap for refine)
        self.s32 = BasicBlock(c16,  c32, stride=2)   # /32 (tap for refine)

        # ARMs + global
        self.arm16 = AttentionRefinement(c16)
        self.arm32 = AttentionRefinement(c32)
        self.global_pool = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c32, c32, kernel_size=1, bias=False),
            nn.BatchNorm2d(c32),
            nn.ReLU(inplace=True),
        )

        # reduce /32 to c16 for merging at /16
        self.reduce32_to_16 = nn.Sequential(
            nn.Conv2d(c32, c16, kernel_size=1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )

        # gentle clean-up after the /16 merge
        self.post_merge_reduce = nn.Sequential(
            nn.Conv2d(c16, c16, kernel_size=1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )

        # expose channel tuple for decoder wiring
        self.skip_channels = (c4, c8, c16, c32)

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        x2  = self.s2(x)        # /2,  c2
        x4  = self.s4(x2)       # /4,  c4  -> skip[0]
        x8  = self.s8(x4)       # /8,  c8  -> skip[1]
        x16 = self.s16(x8)      # /16, c16
        x32 = self.s32(x16)     # /32, c32

        # refine /16 and /32 as in BiSeNet
        gp = self.global_pool(x32)
        x32_arm = self.arm32(x32) + gp          # /32, c32
        x16_arm = self.arm16(x16)               # /16, c16
        x32_red = self.reduce32_to_16(x32_arm)  # /32, c16
        x32_up  = F.interpolate(x32_red, size=x16_arm.shape[-2:], mode="bilinear", align_corners=False)  # -> /16
        x16_ref = self.post_merge_reduce(x16_arm + x32_up)  # /16, c16

        # UNet-like skip order: [1/4, 1/8, 1/16, 1/32]
        return [x4, x8, x16_ref, x32]


# ---- UNet decoder (reused) ----
class _UpBlock(nn.Module):
    def __init__(self, cin: int, skip_ch: int, cout: int):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(cin + skip_ch, cout, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(cout),
            nn.ReLU(inplace=True),
            nn.Conv2d(cout, cout, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(cout),
            nn.ReLU(inplace=True),
        )
    def forward(self, x, skip):  # x is upsampled, same HxW as skip
        x = torch.cat([x, skip], dim=1)
        return self.conv(x)


class UNetDecoder(nn.Module):
    """
    UNet decoder expecting encoder outputs at strides 1/4, 1/8, 1/16, 1/32.
    Channels should match encoder outputs. Uses bilinear upsampling for speed.
    """
    def __init__(self, chs: List[int], out_ch: int = 1):
        super().__init__()
        # chs = [c1_4, c1_8, c1_16, c1_32]
        c1_4, c1_8, c1_16, c1_32 = chs

        self.up1  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = _UpBlock(c1_32, c1_16, c1_16)

        self.up2  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = _UpBlock(c1_16, c1_8,  c1_8)

        self.up3  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = _UpBlock(c1_8,  c1_4,  c1_4)

        self.up4  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.head = nn.Conv2d(c1_4, out_ch, kernel_size=1)

    def forward(self, skips: List[torch.Tensor]) -> torch.Tensor:
        x1_4, x1_8, x1_16, x1_32 = skips

        y = self.up1(x1_32)
        y = self.dec1(y, x1_16)

        y = self.up2(y)
        y = self.dec2(y, x1_8)

        y = self.up3(y)
        y = self.dec3(y, x1_4)

        y = self.up4(y)
        logits = self.head(y)
        logits = F.interpolate(logits, scale_factor=2, mode='bilinear', align_corners=False)
        return logits


# ---- Full hybrid ----
def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


class BiseUNetV1(nn.Module):
    """
    BiSeNet-style encoder (context path + ARMs + global pooling) that outputs
    UNet-style skip pyramid -> UNet decoder -> logits.

    Args:
        in_ch: input channels (3 for RGB)
        out_ch: output channels (1 for binary seg)
        base: base channel multiplier for encoder
    """
    def __init__(self, in_ch: int = 3, out_ch: int = 1, base_ch: int = 32):
        super().__init__()
        self.encoder = BiSeNetEncoderUNetSkips(in_ch=in_ch, base=base_ch)
        self.decoder = UNetDecoder(list(self.encoder.skip_channels), out_ch=out_ch)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        skips = self.encoder(x)   # [1/4, 1/8, 1/16, 1/32]
        logits = self.decoder(skips)
        return logits


if __name__ == "__main__":
    net = BiseUNetV1(in_ch=3, out_ch=1, base_ch=32)
    x = torch.randn(1,3,256,256)
    y = net(x)
    print("Hybrid out:", y.shape)
    print("Params(M):", count_params(net)/1e6)
