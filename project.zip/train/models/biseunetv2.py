# ==============================================
# File: biseunetv2.py
# Stripped-down BiSeNet-encoder + UNet-decoder hybrid (fewer params)
# - Lower channel multipliers than v1
# - Depthwise separable convs throughout
# - Lightweight attention (SE-lite)
# - Lean UNet decoder (single DS block per stage)
# Interface matches v1: BiseUNetV2(in_ch=3, out_ch=1, base=24)  # base is smaller by default
# ==============================================
from typing import List
import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------- Primitives -----------------
class DSConv(nn.Module):
    """Depthwise separable conv: DWConv(k,s,p) + BN + ReLU + PWConv(1x1) + BN + ReLU"""
    def __init__(self, cin, cout, k=3, s=1, p=1):
        super().__init__()
        self.dw = nn.Conv2d(cin, cin, kernel_size=k, stride=s, padding=p, groups=cin, bias=False)
        self.dw_bn = nn.BatchNorm2d(cin)
        self.pw = nn.Conv2d(cin, cout, kernel_size=1, bias=False)
        self.pw_bn = nn.BatchNorm2d(cout)
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        x = self.act(self.dw_bn(self.dw(x)))
        x = self.act(self.pw_bn(self.pw(x)))
        return x


class SE_Lite(nn.Module):
    """Tiny Squeeze-and-Excitation with heavy reduction."""
    def __init__(self, ch, r=8):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Conv2d(ch, max(ch // r, 1), 1, bias=True)
        self.fc2 = nn.Conv2d(max(ch // r, 1), ch, 1, bias=True)
    def forward(self, x):
        w = self.pool(x)
        w = F.relu(self.fc1(w), inplace=True)
        w = torch.sigmoid(self.fc2(w))
        return x * w


class LightBlock(nn.Module):
    """Two DSConvs; first may downsample via stride."""
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.ds1 = DSConv(cin, cout, k=3, s=stride, p=1)
        self.ds2 = DSConv(cout, cout, k=3, s=1, p=1)
    def forward(self, x):
        return self.ds2(self.ds1(x))


# ----------------- Encoder (light BiSeNet context path) -----------------
class LightContextEncoder(nn.Module):
    """
    Produces UNet-style skip pyramid with much fewer params.
    Channel plan with base b (smaller than v1):
        /4  : 1*b
        /8  : 2*b
        /16 : 2*b  (refined)
        /32 : 4*b
    """
    def __init__(self, in_ch: int = 3, base: int = 24):
        super().__init__()
        b = base
        c4, c8, c16, c32 = b, 2*b, 2*b, 4*b

        # Downsample chain using LightBlocks (DS convs)
        self.s2  = LightBlock(in_ch, b,  stride=2)   # /2
        self.s4  = LightBlock(b,     c4, stride=2)   # /4  (skip 1)
        self.s8  = LightBlock(c4,    c8, stride=2)   # /8  (skip 2)
        self.s16 = LightBlock(c8,    c16, stride=2)  # /16
        self.s32 = LightBlock(c16,   c32, stride=2)  # /32

        # Lightweight attention on /16 and /32
        self.att16 = SE_Lite(c16, r=8)
        self.att32 = SE_Lite(c32, r=8)

        # Reduce /32 to /16 channels and upsample for merge
        self.reduce32 = DSConv(c32, c16, k=1, s=1, p=0)
        self.post = DSConv(c16, c16, k=1, s=1, p=0)

        self.skip_channels = (c4, c8, c16, c32)

    def forward(self, x):
        x2  = self.s2(x)        # /2
        x4  = self.s4(x2)       # /4
        x8  = self.s8(x4)       # /8
        x16 = self.s16(x8)      # /16
        x32 = self.s32(x16)     # /32

        x16 = self.att16(x16)
        x32 = self.att32(x32)

        x32r = self.reduce32(x32)  # /32 -> channels c16
        x32u = F.interpolate(x32r, size=x16.shape[-2:], mode="bilinear", align_corners=False)
        x16r = self.post(x16 + x32u)  # refined /16

        # Return UNet-like skips
        return [x4, x8, x16r, x32]


# ----------------- Decoder (lean UNet) -----------------
class _Up(nn.Module):
    def __init__(self, cin, skip_ch, cout):
        super().__init__()
        # Single DS block instead of two heavy convs
        self.fuse = DSConv(cin + skip_ch, cout, k=3, s=1, p=1)
    def forward(self, x, skip):
        x = torch.cat([x, skip], dim=1)
        return self.fuse(x)


class LightUNetDecoder(nn.Module):
    def __init__(self, chs: list, out_ch: int = 1):
        super().__init__()
        c1_4, c1_8, c1_16, c1_32 = chs

        self.up1  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = _Up(c1_32, c1_16, c1_16)

        self.up2  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = _Up(c1_16, c1_8,  c1_8)

        self.up3  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = _Up(c1_8,  c1_4,  c1_4)

        self.up4  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.head = nn.Conv2d(c1_4, out_ch, kernel_size=1)

    def forward(self, skips: List[torch.Tensor]) -> torch.Tensor:
        x1_4, x1_8, x1_16, x1_32 = skips

        y = self.up1(x1_32)
        y = self.dec1(y, x1_16)

        y = self.up2(y)
        y = self.dec2(y, x1_8)

        y = self.up3(y)
        y = self.dec3(y, x1_4)

        y = self.up4(y)              # -> 1/2
        logits = self.head(y)        # -> 1/2
        logits = F.interpolate(logits, scale_factor=2, mode="bilinear", align_corners=False)  # -> 1
        return logits


# ----------------- Full Model -----------------
def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


class BiseUNetV2(nn.Module):
    """
    Stripped hybrid:
      - LightContextEncoder (DSConv + reduced channels)
      - LightUNetDecoder (single DS block per stage)
    Expect substantially fewer params than BiSeNetV1 and BiseUNetV1.
    """
    def __init__(self, in_ch: int = 3, out_ch: int = 1, base_ch: int = 24):
        super().__init__()
        self.encoder = LightContextEncoder(in_ch=in_ch, base=base_ch)
        self.decoder = LightUNetDecoder(list(self.encoder.skip_channels), out_ch=out_ch)

    def forward(self, x):
        skips = self.encoder(x)
        return self.decoder(skips)


if __name__ == "__main__":
    net = BiseUNetV2(in_ch=3, out_ch=1, base=24)
    x = torch.randn(1,3,256,256)
    y = net(x)
    print("out:", y.shape)
    print("params (M):", count_params(net)/1e6)
