# ==============================================
# File: unet_encoder.py
# Minimal UNet encoder (backbone) with skip outputs
# ==============================================
from typing import List, Tuple
import torch
import torch.nn as nn


def _conv_block(cin: int, cout: int) -> nn.Sequential:
    return nn.Sequential(
        nn.Conv2d(cin, cout, kernel_size=3, padding=1, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
        nn.Conv2d(cout, cout, kernel_size=3, padding=1, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )


class UNetEncoder(nn.Module):
    """
    UNet encoder that emits feature maps at strides 1/4, 1/8, 1/16, 1/32.
    Channel config kept small & simple for edge devices; you can scale with base_ch.
    """
    def __init__(self, in_ch: int = 3, base_ch: int = 32):
        super().__init__()
        ch1, ch2, ch3, ch4, ch5 = base_ch, base_ch*2, base_ch*4, base_ch*8, base_ch*16

        self.stem = _conv_block(in_ch, ch1)          # H,   W   -> ch1
        self.pool1 = nn.MaxPool2d(2)                 # H/2, W/2

        self.enc2 = _conv_block(ch1, ch2)
        self.pool2 = nn.MaxPool2d(2)                 # H/4, W/4

        self.enc3 = _conv_block(ch2, ch3)
        self.pool3 = nn.MaxPool2d(2)                 # H/8, W/8

        self.enc4 = _conv_block(ch3, ch4)
        self.pool4 = nn.MaxPool2d(2)                 # H/16, W/16

        self.enc5 = _conv_block(ch4, ch5)            # H/32, W/32 (bottleneck)

    def forward(self, x: torch.Tensor) -> List[torch.Tensor]:
        x1 = self.stem(x)           # stride 1
        x2 = self.enc2(self.pool1(x1))
        x3 = self.enc3(self.pool2(x2))
        x4 = self.enc4(self.pool3(x3))
        x5 = self.enc5(self.pool4(x4))
        # Return UNet-style skips (we'll use from x2 onward for 1/4..1/32)
        return [x2, x3, x4, x5]


if __name__ == "__main__":
    enc = UNetEncoder(in_ch=3, base_ch=32)
    x = torch.randn(1,3,256,256)
    ys = enc(x)
    print("Encoder out shapes:", [y.shape for y in ys])
    total_params = sum(p.numel() for p in enc.parameters())
    print(f"Encoder params: {total_params/1e6:.3f}M")