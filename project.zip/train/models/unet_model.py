# ==============================================
# File: unet_model.py
# Combine encoder + decoder; print parameter counts
# ==============================================
from typing import Tuple
import torch
import torch.nn as nn
from .unet_encoder import UNetEncoder
from .unet_decoder import UNetDecoder


def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


class UNet(nn.Module):
    def __init__(self, in_ch: int = 3, out_ch: int = 1, base_ch: int = 32):
        super().__init__()
        self.encoder = UNetEncoder(in_ch, base_ch)
        # encoder channels: [base*2, base*4, base*8, base*16]
        chs = [base_ch*2, base_ch*4, base_ch*8, base_ch*16]
        self.decoder = UNetDecoder(chs, out_ch)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        skips = self.encoder(x)
        logits = self.decoder(skips)
        return logits


if __name__ == "__main__":
    net = UNet(in_ch=3, out_ch=1, base_ch=32)
    x = torch.randn(1,3,256,256)
    y = net(x)
    print("Model out:", y.shape)
    enc_params = count_params(net.encoder)
    dec_params = count_params(net.decoder)
    tot_params = count_params(net)
    print(f"Encoder params: {enc_params/1e6:.3f}M | Decoder params: {dec_params/1e6:.3f}M | Total: {tot_params/1e6:.3f}M")


