# odise_seg.py
# ------------------------------------------------------------
# ODISE-lite (multi-scale): Frozen Stable Diffusion features (1/16, 1/32, mid)
# + small FPN + binary seg head. Returns LOGITS (B,1,H,W).
# Keep your training loop, losses, AMP as-is.
#
# pip install diffusers transformers safetensors accelerate
# Optional env:
#   ODISE_PROMPT="polyp in colonoscopy, mucosal lesion, adenomatous polyp"
#   ODISE_NEG_PROMPT="instrument, specular highlight, scope border, text overlay"
#   ODISE_GUIDANCE=5.0
# ------------------------------------------------------------

import os
import torch
import torch.nn as nn
import torch.nn.functional as F
from diffusers import AutoencoderKL, UNet2DConditionModel, DDPMScheduler
from transformers import CLIPTextModel, CLIPTokenizer

IMAGENET_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(1,3,1,1)
IMAGENET_STD  = torch.tensor([0.229, 0.224, 0.225]).view(1,3,1,1)
VAE_SCALE = 0.18215

def denorm_imagenet(x):  # x is ImageNet-normalized
    return (x * IMAGENET_STD.to(x.device)) + IMAGENET_MEAN.to(x.device)

def to_vae_range(x01):   # [0,1] -> [-1,1]
    return (x01 * 2.0 - 1.0).clamp(-1, 1)

def conv_bn_relu(cin, cout, k=3, s=1, p=1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )

class ODISELite(nn.Module):
    def __init__(
        self,
        prompt="polyp in colonoscopy, mucosal lesion, adenomatous polyp",
        neg_prompt="instrument, specular highlight, scope border, text overlay",
        sd_repo="runwayml/stable-diffusion-v1-5",
        guidance_scale=5.0,
        eval_timesteps=(0.35, 0.5, 0.7),
        dtype=torch.float16,
        train_backbone=False
    ):
        super().__init__()
        self.prompt = os.environ.get("ODISE_PROMPT", prompt)
        self.neg_prompt = os.environ.get("ODISE_NEG_PROMPT", neg_prompt)
        self.guidance_scale = float(os.environ.get("ODISE_GUIDANCE", guidance_scale))
        self.eval_timesteps = tuple(eval_timesteps)
        self.dtype = dtype

        # --- Stable Diffusion components (frozen) ---
        self.tokenizer = CLIPTokenizer.from_pretrained(sd_repo, subfolder="tokenizer")
        self.text_encoder = CLIPTextModel.from_pretrained(sd_repo, subfolder="text_encoder")
        self.vae = AutoencoderKL.from_pretrained(sd_repo, subfolder="vae")
        self.unet = UNet2DConditionModel.from_pretrained(sd_repo, subfolder="unet")
        self.noise_sched = DDPMScheduler.from_pretrained(sd_repo, subfolder="scheduler")

        for m in (self.text_encoder, self.vae, self.unet):
            m.requires_grad_(train_backbone)
            m.to(dtype=self.dtype)

        # Pre-compute channel sizes from SD UNet config
        chs = list(self.unet.config.block_out_channels)  # e.g., [320, 640, 1280, 1280]
        c16, c32, cmid = chs[1], chs[2], chs[-1]         # feature taps

        # --- FPN reducers (to 256 channels) & smoothers ---
        self.l16 = nn.Conv2d(c16, 256, 1, bias=False)
        self.l32 = nn.Conv2d(c32, 256, 1, bias=False)
        self.lmid = nn.Conv2d(cmid, 256, 1, bias=False)
        self.smooth16 = conv_bn_relu(256, 256, 3, 1, 1)
        self.smooth8  = conv_bn_relu(256, 256, 3, 1, 1)

        # --- Segmentation head (eager; ensures optimizer sees params) ---
        self.seg_head = nn.Sequential(
            nn.Conv2d(256, 128, 3, padding=1, bias=False), nn.BatchNorm2d(128), nn.ReLU(inplace=True),
            nn.Conv2d(128, 64, 3, padding=1, bias=False),  nn.BatchNorm2d(64),  nn.ReLU(inplace=True),
            nn.Conv2d(64, 1, 1)
        )

        # Prompt caches
        self._pos_ctx = None
        self._neg_ctx = None

        self.prompt_adapter = nn.Sequential(
            nn.Linear(768, 768, bias=True),
            nn.ReLU(inplace=True),
            nn.Linear(768, 768, bias=True)
        )

        tune_xattn = os.environ.get("ODISE_TUNE_XATTN", "0") == "1"
        if tune_xattn:
            self._enable_cross_attn_tuning()
        else:
            self._xattn_enabled = False

    def _enable_cross_attn_tuning(self):
        # Freeze all first
        for p in self.unet.parameters():
            p.requires_grad_(False)
        # Enable only cross-attention projections in all blocks
        for n, p in self.unet.named_parameters():
            if "attn2.to_q" in n or "attn2.to_k" in n or "attn2.to_v" in n or "attn2.to_out" in n:
                p.requires_grad_(True)
        self._xattn_enabled = True

    # ---------- helpers ----------
    def _encode_text(self, text, device):
        toks = self.tokenizer(
            [text], padding="max_length",
            max_length=self.tokenizer.model_max_length,
            truncation=True, return_tensors="pt"
        ).input_ids.to(device)
        with torch.no_grad():
            enc = self.text_encoder(toks).last_hidden_state  # (1,77,768)
        return enc

    def _get_ctx(self, device):
        if self._pos_ctx is None:
            self._pos_ctx = self._encode_text(self.prompt, device)
        if self._neg_ctx is None:
            self._neg_ctx = self._encode_text(self.neg_prompt, device)
        pos = self._pos_ctx
        neg = self._neg_ctx
        # apply adapter in fp32 for stability, then cast back
        pos = self.prompt_adapter(pos.float()).to(self.dtype)
        neg = self.prompt_adapter(neg.float()).to(self.dtype)
        return pos, neg
        return self._pos_ctx, self._neg_ctx

    def _img_to_latents(self, x):
        x01 = denorm_imagenet(x).clamp(0, 1)
        x_ = to_vae_range(x01).to(self.vae.dtype)
        with torch.no_grad():
            z = self.vae.encode(x_).latent_dist.sample() * VAE_SCALE  # (B,4,h,w) h=H/8
        return z

    # ---------- feature collection ----------
    def _collect_features(self, z_noisy, t, ctx):
        """
        Run UNet once and capture three feature maps:
        f16 from down_blocks[1], f32 from down_blocks[2], fmid from mid_block.
        Shapes roughly: (B,c16,h/2,w/2), (B,c32,h/4,w/4), (B,cmid,h/8,w/8) where h,w are latent H/8.
        """
        feats = {}

        def hook_down1(_, __, out): feats["f16"] = out
        def hook_down2(_, __, out): feats["f32"] = out
        def hook_mid(_, __, out):   feats["fmid"] = out

        # robustly attach to the last resnet in each block (works across SD1.5 variants)
        h1 = self.unet.down_blocks[1].resnets[-1].register_forward_hook(hook_down1)
        h2 = self.unet.down_blocks[2].resnets[-1].register_forward_hook(hook_down2)
        h3 = self.unet.mid_block.register_forward_hook(hook_mid)

        with torch.no_grad():
            _ = self.unet(
                z_noisy.to(self.unet.dtype),
                t,
                encoder_hidden_states=ctx.to(self.unet.dtype)
            )

        h1.remove(); h2.remove(); h3.remove()
        return feats  # dict with f16,f32,fmid

    def _guided_feats(self, z, t, pos_ctx, neg_ctx):
        """
        Classifier-free guidance on *features*:
        f = f_cond + s*(f_cond - f_uncond), level-wise.
        """
        f_u = self._collect_features(z, t, neg_ctx)
        f_c = self._collect_features(z, t, pos_ctx)
        s = self.guidance_scale
        out = {}
        for k in ("f16","f32","fmid"):
            out[k] = f_c[k] + s * (f_c[k] - f_u[k])
        return out

    # ---------- forward ----------
    def forward(self, x):
        B, _, H, W = x.shape
        device = x.device
        # place modules
        self.text_encoder.to(device); self.unet.to(device); self.vae.to(device)
        self.l16.to(device); self.l32.to(device); self.lmid.to(device)
        self.smooth16.to(device); self.smooth8.to(device); self.seg_head.to(device)

        pos_ctx, neg_ctx = self._get_ctx(device)
        pos_ctx = pos_ctx.repeat(B,1,1)
        neg_ctx = neg_ctx.repeat(B,1,1)

        # VAE latents
        z = self._img_to_latents(x)           # (B,4,hl,wl)
        hl, wl = z.shape[-2:]

        num_t = self.noise_sched.config.num_train_timesteps

        def fuse_pyramid(Fs):
            # reduce to 256 & build top-down pyramid to latent H/8
            f16 = self.l16(Fs["f16"].to(torch.float32))
            f32 = self.l32(Fs["f32"].to(torch.float32))
            fmid= self.lmid(Fs["fmid"].to(torch.float32))

            p32 = f32 + F.interpolate(fmid, size=f32.shape[-2:], mode="bilinear", align_corners=False)
            p16 = f16 + F.interpolate(p32, size=f16.shape[-2:], mode="bilinear", align_corners=False)
            p16 = self.smooth16(p16)
            p8  = F.interpolate(p16, size=(hl, wl), mode="bilinear", align_corners=False)
            p8  = self.smooth8(p8)  # (B,256,hl,wl)
            return p8

        if self.training:
            # random t in [0.3,0.8]
            import random
            tfrac = random.uniform(0.3, 0.8)
            t = torch.full((B,), int(tfrac*(num_t-1)), device=device, dtype=torch.long)
            z_noisy = self.noise_sched.add_noise(z, torch.randn_like(z), t)
            Fs = self._guided_feats(z_noisy, t, pos_ctx, neg_ctx)
            feats = fuse_pyramid(Fs)
        else:
            feats_acc = None
            for tfrac in (0.35, 0.5, 0.7):  # lightweight timestep ensemble
                t = torch.full((B,), int(tfrac*(num_t-1)), device=device, dtype=torch.long)
                z_noisy = self.noise_sched.add_noise(z, torch.randn_like(z), t)
                Fs = self._guided_feats(z_noisy, t, pos_ctx, neg_ctx)
                f = fuse_pyramid(Fs)
                feats_acc = f if feats_acc is None else (feats_acc + f)
            feats = feats_acc / 3.0

        logits_small = self.seg_head(feats)     # (B,1,hl,wl)
        logits = F.interpolate(logits_small, size=(H, W), mode="bilinear", align_corners=False)
        return logits


# -------- factory used by unet_model.build_model -------------
def build_odise(in_channels=3, classes=1, prompt=None, sd_repo="runwayml/stable-diffusion-v1-5"):
    assert in_channels == 3 and classes == 1, "This ODISE-lite expects 3ch input and binary output."
    return ODISELite(
        prompt=prompt or "polyp in colonoscopy, mucosal lesion, adenomatous polyp",
        neg_prompt=os.environ.get("ODISE_NEG_PROMPT", "instrument, specular highlight, scope border, text overlay"),
        sd_repo=os.environ.get("ODISE_SD_REPO", sd_repo),
        guidance_scale=float(os.environ.get("ODISE_GUIDANCE", 5.0)),
        eval_timesteps=(0.35, 0.5, 0.7),
        dtype=torch.float16,
        train_backbone=False
    )
