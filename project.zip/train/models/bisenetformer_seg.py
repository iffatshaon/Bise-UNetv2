# bisenetformer_seg.py
# ------------------------------------------------------------
# BiSeNetFormer-lite for binary semantic segmentation
# - Two-path encoder: Spatial Path (detail, 1/8) + Context Path (timm backbone → FPN to 1/8)
# - Feature Fusion Module with attention (BiSeNet-style)
# - Lightweight mask-classification head (single learned query) guiding the mask
# - Returns raw LOGITS: (B,1,H,W)
# ------------------------------------------------------------

import torch
import torch.nn as nn
import torch.nn.functional as F
import timm


# ---------------------- blocks & helpers ----------------------
def conv_bn_relu(cin, cout, k=3, s=1, p=1, d=1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, dilation=d, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )

class SpatialPath(nn.Module):
    """
    Three strided convs to keep detail at 1/8 resolution.
    """
    def __init__(self, in_ch=3, out_ch=64):
        super().__init__()
        self.conv1 = conv_bn_relu(in_ch, 64, k=7, s=2, p=3)   # 1/2
        self.conv2 = conv_bn_relu(64, 64, k=3, s=2, p=1)      # 1/4
        self.conv3 = conv_bn_relu(64, out_ch, k=3, s=2, p=1)  # 1/8

    def forward(self, x):
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        return x  # (B, 64, H/8, W/8)

class FPNto1_8(nn.Module):
    """
    Simple FPN to bring context backbone features to 1/8 map with fixed C=128.
    Expects features at strides (1/8, 1/16, 1/32).
    """
    def __init__(self, c3, c4, c5, out_c=128):
        super().__init__()
        self.l3 = nn.Conv2d(c3, out_c, 1, bias=False)
        self.l4 = nn.Conv2d(c4, out_c, 1, bias=False)
        self.l5 = nn.Conv2d(c5, out_c, 1, bias=False)
        self.smooth3 = conv_bn_relu(out_c, out_c, k=3, s=1, p=1)
        self.smooth4 = conv_bn_relu(out_c, out_c, k=3, s=1, p=1)

    def forward(self, f3, f4, f5):
        p5 = self.l5(f5)
        p4 = self.l4(f4) + F.interpolate(p5, size=f4.shape[-2:], mode="bilinear", align_corners=False)
        p3 = self.l3(f3) + F.interpolate(p4, size=f3.shape[-2:], mode="bilinear", align_corners=False)
        p4 = self.smooth4(p4)
        p3 = self.smooth3(p3)
        return p3  # (B, 128, H/8, W/8)

class FeatureFusionModule(nn.Module):
    """
    BiSeNet-style fusion of Spatial(64) + Context(128) with channel attention.
    """
    def __init__(self, in_c=64+128, out_c=128, reduction=4):
        super().__init__()
        self.mix = conv_bn_relu(in_c, out_c, k=3, s=1, p=1)
        self.attn = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(out_c, out_c // reduction, 1, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_c // reduction, out_c, 1, bias=True),
            nn.Sigmoid(),
        )

    def forward(self, s, c):
        x = torch.cat([s, c], dim=1)
        x = self.mix(x)
        w = self.attn(x)
        return x * w + x  # (B, 128, H/8, W/8)

class TinyMaskQueryHead(nn.Module):
    """
    Minimal mask-classification head:
    - One learned query (128D) attends to 1/8 tokens via MHA.
    - Attention map (B,1,h*w) is reshaped to (B,1,h,w) to guide logits.
    - Fused features are modulated by the attention map, then a conv head outputs logits.
    """
    def __init__(self, c=128, heads=8):
        super().__init__()
        self.query = nn.Parameter(torch.randn(1, c))  # (1, C)
        self.mha = nn.MultiheadAttention(embed_dim=c, num_heads=heads, batch_first=False)
        self.refine = conv_bn_relu(c, 64, k=3, s=1, p=1)
        self.out = nn.Conv2d(64, 1, 1)
        self.scale = nn.Parameter(torch.tensor(1.0))  # scales the attention modulation

    def forward(self, fused):  # fused: (B,C,h,w), C=128
        B, C, h, w = fused.shape
        tokens = fused.flatten(2).permute(2, 0, 1)      # (S=hw, B, C)
        q = self.query.unsqueeze(1).repeat(1, B, 1)     # (1, B, C)
        # MHA prefers float32 for stability
        tokens32 = tokens.float()
        q32 = q.float()
        _, attn = self.mha(q32, tokens32, tokens32, need_weights=True, average_attn_weights=True)
        # attn: (B, 1, S) → (B,1,h,w)
        attn_map = attn.reshape(B, 1, h, w)
        # modulate fused features (broadcast multiply)
        fused_mod = fused * (1.0 + self.scale * attn_map)  # emphasize attended regions
        x = self.refine(fused_mod)
        logits_small = self.out(x)  # (B,1,h,w)
        return logits_small

class BiSeNetFormerLite(nn.Module):
    """
    Full model: Spatial Path + Context Path (timm backbone → FPN1/8) + Fusion + tiny mask head.
    """
    def __init__(self, in_ch=3, n_classes=1, context_backbone="resnet18", pretrained=True):
        super().__init__()
        # context backbone with feature maps at 1/8, 1/16, 1/32
        self.backbone = timm.create_model(
            context_backbone, features_only=True, out_indices=(2, 3, 4), pretrained=pretrained
        )
        chs = self.backbone.feature_info.channels()  # [c3, c4, c5]
        self.spatial = SpatialPath(in_ch, out_ch=64)
        self.fpn = FPNto1_8(chs[0], chs[1], chs[2], out_c=128)
        self.fuse = FeatureFusionModule(in_c=64+128, out_c=128, reduction=4)
        self.head = TinyMaskQueryHead(c=128, heads=8)

    def forward(self, x):
        B, _, H, W = x.shape
        # Spatial @ 1/8
        s = self.spatial(x)  # (B,64,H/8,W/8)
        # Context features
        feats = self.backbone(x)
        c3, c4, c5 = feats  # strides 8,16,32
        c = self.fpn(c3, c4, c5)  # (B,128,H/8,W/8)
        # Fuse + mask head
        fused = self.fuse(s, c)   # (B,128,H/8,W/8)
        logits_small = self.head(fused)  # (B,1,H/8,W/8)
        # Upsample to input size
        logits = F.interpolate(logits_small, size=(H, W), mode="bilinear", align_corners=False)
        return logits  # raw logits (no sigmoid)

# -------- factory used by unet_model.build_model -------------
def build_bisenetformer(in_channels=3, classes=1, encoder="resnet18", enc_weights="imagenet"):
    pretrained = (enc_weights == "imagenet")
    return BiSeNetFormerLite(in_ch=in_channels, n_classes=classes,
                             context_backbone=encoder, pretrained=pretrained)
