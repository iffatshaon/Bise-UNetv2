# ==============================================
# File: unet_decoder.py
# Minimal UNet decoder that consumes encoder skips
# ==============================================
from typing import List
import torch
import torch.nn as nn


def _up_block(cin: int, skip_ch: int, cout: int) -> nn.Module:
    return nn.Sequential(
        nn.Conv2d(cin + skip_ch, cout, kernel_size=3, padding=1, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
        nn.Conv2d(cout, cout, kernel_size=3, padding=1, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )


class UNetDecoder(nn.Module):
    """
    UNet decoder expecting encoder outputs at strides 1/4, 1/8, 1/16, 1/32.
    channels should match encoder outputs. Uses bilinear upsampling for speed.
    """
    def __init__(self, chs: List[int], out_ch: int = 1):
        super().__init__()
        # chs = [c1_4, c1_8, c1_16, c1_32]
        c1_4, c1_8, c1_16, c1_32 = chs

        self.up1 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = _up_block(c1_32, c1_16, c1_16)

        self.up2 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = _up_block(c1_16, c1_8, c1_8)

        self.up3 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = _up_block(c1_8, c1_4, c1_4)

        # one more up to get back to stride 1
        self.up4 = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.head = nn.Conv2d(c1_4, out_ch, kernel_size=1)

    def forward(self, skips: List[torch.Tensor]) -> torch.Tensor:
        x1_4, x1_8, x1_16, x1_32 = skips

        y = self.up1(x1_32)
        y = self.dec1(torch.cat([y, x1_16], dim=1))

        y = self.up2(y)
        y = self.dec2(torch.cat([y, x1_8], dim=1))

        y = self.up3(y)
        y = self.dec3(torch.cat([y, x1_4], dim=1))

        y = self.up4(y)
        logits = self.head(y)
        return logits


if __name__ == "__main__":
    import torch
    # Fake encoder channel sizes: [64, 128, 256, 512]
    dec = UNetDecoder([64,128,256,512], out_ch=1)
    skips = [torch.randn(1,64,64,64), torch.randn(1,128,32,32), torch.randn(1,256,16,16), torch.randn(1,512,8,8)]
    y = dec(skips)
    print("Decoder out:", y.shape)
    total_params = sum(p.numel() for p in dec.parameters())
    print(f"Decoder params: {total_params/1e6:.3f}M")


