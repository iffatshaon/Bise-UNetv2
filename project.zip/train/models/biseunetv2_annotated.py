# ===============================================================
# File: biseunetv2_annotated.py
# Title: BiseUNetV2 (Stripped-down BiSeNet-encoder + UNet-decoder)
#
# PURPOSE
# -------
# This is a parameter‑reduced successor to the original "BiseUNetV1"
# hybrid (BiSeNet encoder + UNet decoder). It preserves the same
# input/output behavior and UNet‑style skip layout while substantially
# reducing parameters and compute.
#
# WHAT CHANGED (V1 → V2)
# ----------------------
# 1) Channel plan (encoder):
#    - v1: /4: 2b, /8: 4b, /16: 4b(refined), /32: 8b
#    - v2: /4: 1b, /8: 2b, /16: 2b(refined), /32: 4b
#    => Halved channels across stages → params/FLOPs ↓≈ quadratic in C.
#
# 2) Convolutions:
#    - v1: Standard Conv2d (3x3) blocks (two per stage in encoder & decoder)
#    - v2: Depthwise‑separable convs (DW 3x3 + PW 1x1) everywhere
#    => Params ~ 9*C_in*C_out  →  9*C_in + C_in*C_out  (often 3–8× smaller)
#
# 3) Attention / context refinement:
#    - v1: ARM(16), ARM(32) + global pooling + 1x1 reductions + post‑merge conv
#    - v2: SE‑Lite (two 1x1 convs with strong reduction) on /16 and /32,
#          then a single 1x1 DSConv to reduce /32→/16 and another 1x1 DSConv
#          after merge (post)
#    => Preserves channel‑wise gating with far fewer params/ops.
#
# 4) Decoder per‑stage fusion:
#    - v1: After upsample+concat, TWO full 3x3 convs
#    - v2: After upsample+concat, ONE depthwise‑separable conv
#    => Fewer layers and cheaper ops per stage.
#
# 5) Output size handling:
#    - v1: 4x upsample then (in the last patch) ensured final bilinear upsample
#    - v2: Same idea; explicitly upsamples logits to full input size
#    => Guarantees logits and masks have identical spatial size.
#
# API (unchanged vs v1)
# ---------------------
#   net = BiseUNetV2(in_ch=3, out_ch=1, base=24)
#     - in_ch   : input channels (3 for RGB)
#     - out_ch  : binary seg → 1
#     - base    : base width (smaller default than v1: 24 instead of 32)
#
# NOTE
# ----
# Checkpoints between V1 and V2 are NOT compatible (different shapes/names).
# Train V2 from scratch or write a custom partial‑load adapter.
# ===============================================================

from typing import List
import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------- Primitives -----------------
class DSConv(nn.Module):
    """
    Depthwise‑separable conv block
    v1: used standard Conv2d(3x3) twice
    v2: DWConv(3x3, groups=C_in) + BN + ReLU, then PWConv(1x1) + BN + ReLU
    """
    def __init__(self, cin, cout, k=3, s=1, p=1):
        super().__init__()
        self.dw = nn.Conv2d(cin, cin, kernel_size=k, stride=s, padding=p, groups=cin, bias=False)
        self.dw_bn = nn.BatchNorm2d(cin)
        self.pw = nn.Conv2d(cin, cout, kernel_size=1, bias=False)
        self.pw_bn = nn.BatchNorm2d(cout)
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        x = self.act(self.dw_bn(self.dw(x)))
        x = self.act(self.pw_bn(self.pw(x)))
        return x


class SE_Lite(nn.Module):
    """
    Lightweight channel attention
    v1: ARM + global context (heavier)
    v2: SE‑Lite (two 1x1 convs with strong reduction) → far fewer params
    """
    def __init__(self, ch, r=8):
        super().__init__()
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.fc1 = nn.Conv2d(ch, max(ch // r, 1), 1, bias=True)
        self.fc2 = nn.Conv2d(max(ch // r, 1), ch, 1, bias=True)
    def forward(self, x):
        w = self.pool(x)
        w = F.relu(self.fc1(w), inplace=True)
        w = torch.sigmoid(self.fc2(w))
        return x * w


class LightBlock(nn.Module):
    """
    Two DSConv blocks; first may downsample (stride>1)
    v1: BasicBlock with full 3x3 convs
    v2: DSConv‑based
    """
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.ds1 = DSConv(cin, cout, k=3, s=stride, p=1)
        self.ds2 = DSConv(cout, cout, k=3, s=1, p=1)
    def forward(self, x):
        return self.ds2(self.ds1(x))


# ----------------- Encoder (light BiSeNet context path) -----------------
class LightContextEncoder(nn.Module):
    """
    Produces UNet‑style skip pyramid with fewer params.

    Channel plan (b = base):
      v1: /4: 2b, /8: 4b, /16: 4b(refined), /32: 8b
      v2: /4: 1b, /8: 2b, /16: 2b(refined), /32: 4b

    Skips returned in UNet order: [1/4, 1/8, 1/16, 1/32]
    """
    def __init__(self, in_ch: int = 3, base: int = 24):
        super().__init__()
        b = base
        c4, c8, c16, c32 = b, 2*b, 2*b, 4*b  # v2 thinner plan

        # v1: BasicBlock (full convs) → v2: LightBlock (DS convs)
        self.s2  = LightBlock(in_ch, b,  stride=2)   # /2
        self.s4  = LightBlock(b,     c4, stride=2)   # /4  (skip 1)
        self.s8  = LightBlock(c4,    c8, stride=2)   # /8  (skip 2)
        self.s16 = LightBlock(c8,    c16, stride=2)  # /16
        self.s32 = LightBlock(c16,   c32, stride=2)  # /32

        # v1: ARM16/ARM32 + global pooling
        # v2: SE‑Lite on /16 and /32 (lighter)
        self.att16 = SE_Lite(c16, r=8)
        self.att32 = SE_Lite(c32, r=8)

        # v1: 1x1 conv reduce (c32→c16) + upsample + post‑merge conv
        # v2: same topology but use DSConv(1x1) to keep it light
        self.reduce32 = DSConv(c32, c16, k=1, s=1, p=0)
        self.post = DSConv(c16, c16, k=1, s=1, p=0)

        self.skip_channels = (c4, c8, c16, c32)

    def forward(self, x):
        x2  = self.s2(x)        # /2
        x4  = self.s4(x2)       # /4
        x8  = self.s8(x4)       # /8
        x16 = self.s16(x8)      # /16
        x32 = self.s32(x16)     # /32

        x16 = self.att16(x16)   # v2: SE‑Lite instead of ARM
        x32 = self.att32(x32)

        x32r = self.reduce32(x32)  # /32 -> channels c16 (light 1x1 DSConv)
        x32u = F.interpolate(x32r, size=x16.shape[-2:], mode="bilinear", align_corners=False)
        x16r = self.post(x16 + x32u)  # refined /16 (light 1x1 DSConv)

        return [x4, x8, x16r, x32]


# ----------------- Decoder (lean UNet) -----------------
class _Up(nn.Module):
    """
    v1: after upsample+concat → TWO full 3x3 convs
    v2: after upsample+concat → ONE DSConv (much cheaper)
    """
    def __init__(self, cin, skip_ch, cout):
        super().__init__()
        self.fuse = DSConv(cin + skip_ch, cout, k=3, s=1, p=1)
    def forward(self, x, skip):
        x = torch.cat([x, skip], dim=1)
        return self.fuse(x)


class LightUNetDecoder(nn.Module):
    """
    Keeps the classic 4‑stage UNet upsampling ladder but
    uses a single DSConv for fusion at each stage.
    """
    def __init__(self, chs: list, out_ch: int = 1):
        super().__init__()
        c1_4, c1_8, c1_16, c1_32 = chs

        self.up1  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = _Up(c1_32, c1_16, c1_16)

        self.up2  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = _Up(c1_16, c1_8,  c1_8)

        self.up3  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = _Up(c1_8,  c1_4,  c1_4)

        self.up4  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.head = nn.Conv2d(c1_4, out_ch, kernel_size=1)

    def forward(self, skips: List[torch.Tensor]) -> torch.Tensor:
        x1_4, x1_8, x1_16, x1_32 = skips

        y = self.up1(x1_32)
        y = self.dec1(y, x1_16)

        y = self.up2(y)
        y = self.dec2(y, x1_8)

        y = self.up3(y)
        y = self.dec3(y, x1_4)

        y = self.up4(y)              # -> 1/2
        logits = self.head(y)        # -> 1/2
        # ensure full‑res logits (match mask size)
        logits = F.interpolate(logits, scale_factor=2, mode="bilinear", align_corners=False)  # -> 1
        return logits


# ----------------- Full Model -----------------
def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


class BiseUNetV2(nn.Module):
    """
    Final stripped hybrid:
      - LightContextEncoder (DSConv + reduced channels)
      - LightUNetDecoder (single DSConv fusion per stage)
    """
    def __init__(self, in_ch: int = 3, out_ch: int = 1, base: int = 24):
        super().__init__()
        self.encoder = LightContextEncoder(in_ch=in_ch, base=base)
        self.decoder = LightUNetDecoder(list(self.encoder.skip_channels), out_ch=out_ch)

    def forward(self, x):
        skips = self.encoder(x)
        return self.decoder(skips)


if __name__ == "__main__":
    net = BiseUNetV2(in_ch=3, out_ch=1, base=24)
    x = torch.randn(1,3,256,256)
    y = net(x)
    print("out:", y.shape)
    print("params (M):", count_params(net)/1e6)
