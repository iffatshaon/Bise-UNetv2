# ==============================================
# File: hardnet_model.py
# HarDNet-style encoder + UNet-style decoder for binary segmentation
# API: HardUNet(in_ch=3, out_ch=1, base_ch=32)
# Output: logits same H×W as input
# ==============================================
from typing import List, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---- Small helpers ----
def _conv_bn_relu(cin, cout, k=3, s=1, p=1, groups=1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, bias=False, groups=groups),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )

class DSConv(nn.Module):
    """Depthwise-separable convolution: DW 3×3 + PW 1×1 (used in the decoder for parameter efficiency)."""
    def __init__(self, cin, cout, k=3, s=1, p=1):
        super().__init__()
        self.dw = nn.Conv2d(cin, cin, k, s, p, groups=cin, bias=False)
        self.dw_bn = nn.BatchNorm2d(cin)
        self.pw = nn.Conv2d(cin, cout, 1, bias=False)
        self.pw_bn = nn.BatchNorm2d(cout)
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        x = self.act(self.dw_bn(self.dw(x)))
        x = self.act(self.pw_bn(self.pw(x)))
        return x


# ---- A light HarDNet-style block ----
class HarDBlock(nn.Module):
    """
    A light, HarDNet-inspired dense block.
    - L layers; each produces 'growth' channels with 3×3 conv.
    - Layer i takes a subset of previous outputs (harmonic-like: last, i-2, i-4, ... when available).
    - Final output is a concatenation of all layer outputs (optionally compressed by a 1×1 outside).
    This keeps strong feature reuse while staying simple and fast.
    """
    def __init__(self, in_ch: int, growth: int, layers: int):
        super().__init__()
        self.layers = layers
        self.growth = growth

        convs = []
        in_channels_per_layer = []
        for i in range(layers):
            # pick a small subset of prior layers to emulate “harmonic” connectivity
            # (current, last, last-2, last-4 if exist)
            links = []
            # always include the running input (concatenated so far)
            # but to keep params in check, we simulate by limiting to a few recents
            # build "virtual" in_ch for this layer:
            #   start with in_ch + number_of_selected_previous * growth
            # for simplicity, we approximate by: base_in + min(i,3)*growth
            eff_in = in_ch + min(i, 3) * growth
            in_channels_per_layer.append(eff_in)
            convs.append(_conv_bn_relu(eff_in, growth, k=3, s=1, p=1))

        self.convs = nn.ModuleList(convs)

    def forward(self, x):
        feats: List[torch.Tensor] = []
        running = x
        for i, conv in enumerate(self.convs):
            # build a small concat buffer with a few latest outputs to emulate harmonic links
            if i == 0:
                xin = running
            else:
                # concat last K (=3) features with the original input
                K = 3
                take = feats[-K:] if len(feats) >= K else feats
                xin = torch.cat([running] + list(take), dim=1)
            y = conv(xin)
            feats.append(y)
            # update running ONLY with original input x (to keep effective in_ch bounded)
            # note: running keeps the original input tensor 'x' (not concatenated growth),
            # so subsequent layers don't explode in channel count
            running = x
        # output is concat of all produced feature maps
        return torch.cat(feats, dim=1)


class HarDStage(nn.Module):
    """
    One stage = HarDBlock + optional 1×1 compress + (stride-2) downsample.
    Outputs a downsampled feature with 'out_ch' channels.
    """
    def __init__(self, in_ch: int, growth: int, layers: int, out_ch: int):
        super().__init__()
        self.block = HarDBlock(in_ch, growth, layers)
        block_out = growth * layers
        self.compress = _conv_bn_relu(block_out, out_ch, k=1, s=1, p=0)
        self.down = _conv_bn_relu(out_ch, out_ch, k=3, s=2, p=1)

    def forward(self, x):
        y = self.block(x)
        y = self.compress(y)
        y = self.down(y)
        return y


# ---- Decoder (UNet-style with DSConv per stage) ----
class _UpCatFuse(nn.Module):
    def __init__(self, cin: int, skip_ch: int, cout: int):
        super().__init__()
        self.fuse = DSConv(cin + skip_ch, cout, 3, 1, 1)
    def forward(self, x, skip):
        x = torch.cat([x, skip], dim=1)
        return self.fuse(x)

class UNetDecoderLite(nn.Module):
    """
    Expects skip channels (c4, c8, c16, c32) from the encoder, similar to UNet.
    Decoding path: /32→/16→/8→/4→/2→/1
    """
    def __init__(self, chs: Tuple[int,int,int,int], out_ch=1):
        super().__init__()
        c4, c8, c16, c32 = chs

        self.up1  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)  # /32->/16
        self.dec1 = _UpCatFuse(c32, c16, c16)

        self.up2  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)  # /16->/8
        self.dec2 = _UpCatFuse(c16, c8,  c8)

        self.up3  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)  # /8->/4
        self.dec3 = _UpCatFuse(c8,  c4,  c4)

        self.up4  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)  # /4->/2
        self.head = nn.Conv2d(c4, out_ch, 1)

    def forward(self, skips: List[torch.Tensor]):
        s4, s8, s16, s32 = skips

        y = self.up1(s32)
        y = self.dec1(y, s16)

        y = self.up2(y)
        y = self.dec2(y, s8)

        y = self.up3(y)
        y = self.dec3(y, s4)

        y = self.up4(y)
        logits = self.head(y)                     # /2
        logits = F.interpolate(logits, scale_factor=2, mode="bilinear", align_corners=False)  # -> /1
        return logits


# ---- Full model ----
class HardUNet(nn.Module):
    """
    HarDNet-style encoder (4 stages) + UNet-lite decoder (DSConv).
    - in_ch: input channels (3 for RGB)
    - out_ch: #classes (1 for binary)
    - base_ch: sets channel plan: [c4=2b, c8=4b, c16=4b, c32=8b]
    """
    def __init__(self, in_ch=3, out_ch=1, base_ch=32):
        super().__init__()
        b = base_ch
        c2, c4, c8, c16, c32 = b, 2*b, 4*b, 4*b, 8*b

        # Stem → /2
        self.stem = nn.Sequential(
            _conv_bn_relu(in_ch, b, k=3, s=2, p=1),   # /2, C=b
            _conv_bn_relu(b,   b, k=3, s=1, p=1),
        )

        # Encoder stages (each downsamples by 2)
        # You can tweak (growth, layers) to trade accuracy/params.
        self.stage4 = HarDStage(b,   growth=b,   layers=3, out_ch=c4)   # -> /4
        self.stage8 = HarDStage(c4,  growth=b*2, layers=3, out_ch=c8)   # -> /8
        self.stage16= HarDStage(c8,  growth=b*2, layers=3, out_ch=c16)  # -> /16
        self.stage32= HarDStage(c16, growth=b*4, layers=2, out_ch=c32)  # -> /32

        self.skip_channels = (c4, c8, c16, c32)
        self.decoder = UNetDecoderLite(self.skip_channels, out_ch=out_ch)

    def forward(self, x):
        # Encoder
        x2 = self.stem(x)          # /2, C=b
        s4 = self.stage4(x2)       # /4, C=2b
        s8 = self.stage8(s4)       # /8, C=4b
        s16= self.stage16(s8)      # /16,C=4b
        s32= self.stage32(s16)     # /32,C=8b

        # Decoder (UNet-style)
        logits = self.decoder([s4, s8, s16, s32])
        return logits


# ---- Utility ----
def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


if __name__ == "__main__":
    net = HardUNet(in_ch=3, out_ch=1, base_ch=32)
    x = torch.randn(1,3,256,256)
    y = net(x)
    print("out:", y.shape)
    print("params (M):", count_params(net)/1e6)
