# ==============================================
# File: bisenetv6.py
# BiSe-UNet V6 (SP + CP) + HardUNet-inspired PEG + Local Self-Attention
#
# What's new vs v5:
#   • Adds PEG (3x3, zero-padded) + Local Self-Attention (LSA) at /16 (default ON)
#   • Optional PEG+LSA at /8 (default OFF to keep params/FPS similar)
# Kept from v5:
#   • Pre-Stage-1 fusion at /16: fuse[ ARM@/16 , up( reduce(ARM@/32) ), down(SP@/8) ]
#   • Optional residual FFM_light at /8 (ultralight, gated)
#   • Light UNet-style decoder using DSConv
# ==============================================
from typing import List, Tuple
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------- Small building blocks ----------
def _conv_bn_relu(cin, cout, k=3, s=1, p=1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )

class DSConv(nn.Module):
    """Depthwise-separable conv used for light decoder/fusions."""
    def __init__(self, cin, cout, k=3, s=1, p=1):
        super().__init__()
        self.dw = nn.Conv2d(cin, cin, k, s, p, groups=cin, bias=False)
        self.dw_bn = nn.BatchNorm2d(cin)
        self.pw = nn.Conv2d(cin, cout, 1, bias=False)
        self.pw_bn = nn.BatchNorm2d(cout)
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        x = self.act(self.dw_bn(self.dw(x)))
        x = self.act(self.pw_bn(self.pw(x)))
        return x


# ---------- Position Encoding Generator (HardUNet-style) ----------
class PEG(nn.Module):
    """3x3 conv with zero padding to inject absolute position cues."""
    def __init__(self, ch: int):
        super().__init__()
        self.pe = nn.Conv2d(ch, ch, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn = nn.BatchNorm2d(ch)
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        return self.act(self.bn(self.pe(x)))


# ---------- Local Self-Attention (windowed, padding-safe) ----------
class LSA(nn.Module):
    """
    Local Self-Attention in w×w windows with cheap QKV:
      - depthwise 3x3 + pointwise 1x1 to produce Q,K,V (ratio-controlled)
      - MHSA inside each window
      - window padding handled automatically (replicate pad), then crop back
    """
    def __init__(self, ch, heads=4, window=8, qkv_ratio=0.5, mlp_ratio=2.0, drop=0.0):
        super().__init__()
        self.win = window
        self.heads = heads
        mid = max(8, int(ch * qkv_ratio))

        # cheap qkv
        self.qkv_dw = nn.Conv2d(ch, ch, 3, 1, 1, groups=ch, bias=False)
        self.qkv_pw = nn.Conv2d(ch, 3*mid, 1, bias=False)
        self.qkv_bn = nn.BatchNorm2d(3*mid)

        self.proj = nn.Conv2d(mid, ch, 1, bias=False)
        self.proj_bn = nn.BatchNorm2d(ch)
        self.drop = nn.Dropout(drop)

        self.norm1 = nn.BatchNorm2d(ch)
        self.mlp = nn.Sequential(
            nn.Conv2d(ch, int(ch*mlp_ratio), 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(int(ch*mlp_ratio), ch, 1, bias=False),
            nn.BatchNorm2d(ch),
        )

    def _pad_to_window(self, x):
        B, C, H, W = x.shape
        w = self.win
        pad_h = (w - (H % w)) % w
        pad_w = (w - (W % w)) % w
        if pad_h or pad_w:
            x = F.pad(x, (0, pad_w, 0, pad_h), mode="replicate")
        return x, pad_h, pad_w

    def _partition(self, x):
        B, C, H, W = x.shape
        w = self.win
        x = x.view(B, C, H//w, w, W//w, w).permute(0,2,4,1,3,5)  # B, H/w, W/w, C, w, w
        x = x.reshape(-1, C, w, w)                               # (B * H/w * W/w), C, w, w
        return x, (B, C, H, W)

    def _reverse(self, x, shape, pad_h, pad_w):
        (B, C, H, W) = shape
        w = self.win
        x = x.view(B, H//w, W//w, C, w, w).permute(0,3,1,4,2,5).contiguous()
        x = x.view(B, C, H, W)
        if pad_h or pad_w:
            x = x[:, :, :H - pad_h if pad_h else H, :W - pad_w if pad_w else W]
        return x

    def forward(self, x):
        B, C, H, W = x.shape
        y = self.norm1(x)

        qkv = self.qkv_pw(self.qkv_dw(y))
        qkv = self.qkv_bn(qkv)
        q, k, v = torch.chunk(qkv, 3, dim=1)  # B, mid, H, W

        # pad to window
        q, ph, pw = self._pad_to_window(q)
        k, _, _   = self._pad_to_window(k)
        v, _, _   = self._pad_to_window(v)

        # partition
        q, shape = self._partition(q)  # (Bn, Cm, w, w)
        k, _     = self._partition(k)
        v, _     = self._partition(v)

        Bn, Cm, w, _ = q.shape
        N = w*w
        h = self.heads
        d = Cm // h

        q = q.view(Bn, h, d, N).transpose(2,3)      # Bn, h, N, d
        k = k.view(Bn, h, d, N).transpose(2,3)
        v = v.view(Bn, h, d, N).transpose(2,3)

        att = (q @ k.transpose(-2, -1)) / math.sqrt(d)
        att = att.softmax(dim=-1)
        out = att @ v                                 # Bn, h, N, d
        out = out.transpose(2,3).reshape(Bn, Cm, w, w)

        # reverse windows, crop padding, project back
        out = self._reverse(out, shape, ph, pw)
        out = self.drop(self.proj_bn(self.proj(out)))

        # residual + MLP
        out = out + x
        out = self.mlp(out) + out
        return out


# ---------- BiSeNet Spatial Path (ends at /8) ----------
class SpatialPath(nn.Module):
    """Shallow, high-res path: /2 → /4 → /8, then 1×1 projection."""
    def __init__(self, in_ch=3, base=32):
        super().__init__()
        self.layer1 = _conv_bn_relu(in_ch, base, k=7, s=2, p=3)  # /2
        self.layer2 = _conv_bn_relu(base, base, k=3, s=2, p=1)   # /4
        self.layer3 = _conv_bn_relu(base, base, k=3, s=2, p=1)   # /8
        self.proj   = _conv_bn_relu(base, base, k=1, s=1, p=0)   # /8, C=base
        self.out_ch = base
    def forward(self, x):
        x = self.layer1(x); x = self.layer2(x); x = self.layer3(x)
        return self.proj(x)  # /8, C=base


# ---------- BiSeNet Context Path (with optional PEG+LSA at /16 and /8) ----------
class AttentionRefinement(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch, ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(ch),
            nn.ReLU(inplace=True),
        )
        self.att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(ch, ch, 1, bias=False),
            nn.BatchNorm2d(ch),
            nn.Sigmoid(),
        )
    def forward(self, x):
        feat = self.conv(x)
        return feat * self.att(feat)

class BasicBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.block = nn.Sequential(
            _conv_bn_relu(cin, cout, 3, stride, 1),
            _conv_bn_relu(cout, cout, 3, 1, 1),
        )
    def forward(self, x): return self.block(x)

class ContextPath(nn.Module):
    """
    Downsample to /32 with taps at /4, /8, /16(refined), /32.
    Channel plan (base=b): c4=b*2, c8=b*4, c16=b*4, c32=b*8.
    Optional PEG+LSA at /16 (default True) and /8 (default False).
    """
    def __init__(self, in_ch=3, base=32, use_peg_lsa_16: bool = True, use_peg_lsa_8: bool = False):
        super().__init__()
        b = base
        c2, c4, c8, c16, c32 = b, 2*b, 4*b, 4*b, 8*b
        self.s2  = BasicBlock(in_ch, c2,  stride=2)  # /2
        self.s4  = BasicBlock(c2,   c4,  stride=2)   # /4  (skip)
        self.s8  = BasicBlock(c4,   c8,  stride=2)   # /8  (skip)
        self.s16 = BasicBlock(c8,   c16, stride=2)   # /16
        self.s32 = BasicBlock(c16,  c32, stride=2)   # /32

        self.arm16 = AttentionRefinement(c16)
        self.arm32 = AttentionRefinement(c32)
        self.gp = nn.Sequential(  # global context on /32
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c32, c32, 1, bias=False),
            nn.BatchNorm2d(c32),
            nn.ReLU(inplace=True),
        )
        self.reduce32_to_16 = nn.Sequential(
            nn.Conv2d(c32, c16, 1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )
        self.post_merge_reduce = nn.Sequential(
            nn.Conv2d(c16, c16, 1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )

        # HardUNet-style enhancements
        self.use_peg_lsa_16 = use_peg_lsa_16
        self.use_peg_lsa_8  = use_peg_lsa_8
        if use_peg_lsa_16:
            self.peg16 = PEG(c16)
            self.lsa16 = LSA(c16, heads=4, window=8, qkv_ratio=0.5, mlp_ratio=2.0)
        if use_peg_lsa_8:
            self.peg8 = PEG(c8)
            self.lsa8 = LSA(c8, heads=4, window=8, qkv_ratio=0.5, mlp_ratio=2.0)

        self.skip_channels = (c4, c8, c16, c32)

    def forward(self, x):
        x2  = self.s2(x)
        x4  = self.s4(x2)
        x8  = self.s8(x4)
        if self.use_peg_lsa_8:
            x8 = self.peg8(x8)
            x8 = self.lsa8(x8)

        x16 = self.s16(x8)
        x32 = self.s32(x16)

        x32_ref = self.arm32(x32) + self.gp(x32)
        x16_ref = self.arm16(x16)

        x32_red = self.reduce32_to_16(x32_ref)
        x32_up  = F.interpolate(x32_red, size=x16_ref.shape[-2:], mode="bilinear", align_corners=False)
        x16_ref = self.post_merge_reduce(x16_ref + x32_up)  # refined /16

        if self.use_peg_lsa_16:
            x16_ref = self.peg16(x16_ref)
            x16_ref = self.lsa16(x16_ref)

        return x4, x8, x16_ref, x32  # UNet-style skips


# ---------- Pre-Stage-1 fusion at /16 (ARM16~x16_ref + up32 + down(SP/8)) ----------
class PreStage1Fusion(nn.Module):
    """
    Downsample SP/8 -> /16 (cheap), then fuse [x16_ref, up32_like, sp16] and compress to c16.
    Residual add with x16_ref for stability. SP contribution is gated.
    """
    def __init__(self, c_sp: int, c16: int, sp_down_ratio: int = 4, enable_residual: bool = True):
        super().__init__()
        c_sp_red = max(c16 // sp_down_ratio, 1)
        self.sp_down = nn.Sequential(
            DSConv(c_sp, c_sp, k=3, s=2, p=1),  # /8 -> /16 depthwise-separable
            nn.Conv2d(c_sp, c_sp_red, 1, bias=False),
            nn.BatchNorm2d(c_sp_red),
            nn.ReLU(inplace=True),
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(c16 + c16 + c_sp_red, c16, kernel_size=1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )
        self.enable_residual = enable_residual
        self.sp_gate = nn.Parameter(torch.tensor(0.8))  # learnable gate on SP

    def forward(self, x16_ref: torch.Tensor, up32_like: torch.Tensor, sp8: torch.Tensor):
        sp16 = self.sp_down(sp8)
        g = torch.sigmoid(self.sp_gate)
        x = torch.cat([x16_ref, up32_like, g * sp16], dim=1)  # /16
        out = self.fuse(x)
        if self.enable_residual:
            out = out + x16_ref
        return out  # /16, C=c16


# ---------- Optional: ultralight residual FFM at /8 ----------
class FFMLight(nn.Module):
    """Residual fusion at /8: x8' = x8 + β · φ([x8, reduce(sp8)])"""
    def __init__(self, c8: int, c_sp: int, sp_reduce_ratio: int = 4):
        super().__init__()
        c_sp_red = max(c8 // sp_reduce_ratio, 1)
        self.sp_reduce = nn.Conv2d(c_sp, c_sp_red, 1, bias=False)
        self.fuse = nn.Sequential(
            DSConv(c8 + c_sp_red, c8, k=3, s=1, p=1),
        )
        self.ffm_gate = nn.Parameter(torch.tensor(0.5))  # learnable β

    def forward(self, x8: torch.Tensor, sp8: torch.Tensor):
        sp_r = self.sp_reduce(sp8)
        y = torch.cat([x8, sp_r], dim=1)
        y = self.fuse(y)
        beta = torch.sigmoid(self.ffm_gate)
        return x8 + beta * y  # residual


# ---------- UNet decoder (light v3: DSConv per stage) ----------
class _UpLite(nn.Module):
    def __init__(self, cin, skip_ch, cout):
        super().__init__()
        self.fuse = DSConv(cin + skip_ch, cout, 3, 1, 1)
    def forward(self, x, skip):
        x = torch.cat([x, skip], dim=1)
        return self.fuse(x)

class UNetDecoderV3(nn.Module):
    def __init__(self, chs: Tuple[int,int,int,int], out_ch=1):
        super().__init__()
        c1_4, c1_8, c1_16, c1_32 = chs
        self.up1  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = _UpLite(c1_32, c1_16, c1_16)

        self.up2  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = _UpLite(c1_16, c1_8,  c1_8)

        self.up3  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = _UpLite(c1_8,  c1_4,  c1_4)

        self.up4  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.head = nn.Conv2d(c1_4, out_ch, 1)

    def forward(self, skips: List[torch.Tensor]):
        x1_4, x1_8, x1_16, x1_32 = skips

        y = self.up1(x1_32)     # /32 -> /16
        y = self.dec1(y, x1_16) # fuse /16

        y = self.up2(y)         # /16 -> /8
        y = self.dec2(y, x1_8)  # fuse /8

        y = self.up3(y)         # /8 -> /4
        y = self.dec3(y, x1_4)  # fuse /4

        y = self.up4(y)         # /4 -> /2
        logits = self.head(y)   # /2
        logits = F.interpolate(logits, scale_factor=2, mode="bilinear", align_corners=False)  # -> /1
        return logits


# ---------- Full model: BiSe-UNet V6 ----------
class BiseUNetV6(nn.Module):
    """
    BiSe-UNet V6:
      - ContextPath (+PEG+LSA at /16, optional at /8) provides skips: x4(/4), x8(/8), x16_ref(/16), x32(/32)
      - SpatialPath provides sp8(/8)
      - Pre-Stage-1 fusion at /16: skip16 = fuse(x16_ref, up32_like, down(SP@/8))
      - Optional residual FFM_light at /8 (x8' = x8 + β·φ([x8, sp8]))
      - Light UNet decoder (v3) consumes [x4, x8' (or x8), skip16, x32]
    """
    def __init__(
        self,
        in_ch=3,
        out_ch=1,
        base_ch=32,
        use_sp: bool = True,
        use_ffm_light: bool = True,
        use_peg_lsa_16: bool = True,
        use_peg_lsa_8: bool  = False,
    ):
        super().__init__()
        self.cp = ContextPath(in_ch=in_ch, base=base_ch,
                              use_peg_lsa_16=use_peg_lsa_16,
                              use_peg_lsa_8=use_peg_lsa_8)
        self.use_sp = use_sp
        self.use_ffm_light = use_ffm_light

        if use_sp:
            self.sp = SpatialPath(in_ch=in_ch, base=base_ch)   # /8, C=base
            c8  = 4 * base_ch
            c16 = 4 * base_ch
            # Pre-stage-1 fusion at /16 (with gated SP)
            self.pre1 = PreStage1Fusion(c_sp=self.sp.out_ch, c16=c16, sp_down_ratio=4, enable_residual=True)
            # Optional ultralight residual FFM at /8
            if use_ffm_light:
                self.ffm = FFMLight(c8=c8, c_sp=self.sp.out_ch, sp_reduce_ratio=4)
        else:
            self.pre1 = None
            self.ffm = None

        # Decoder expects the original CP skip widths (c4, c8, c16, c32)
        self.decoder = UNetDecoderV3(self.cp.skip_channels, out_ch=out_ch)

    def forward(self, x):
        # CP skips (with PEG+LSA applied inside CP if enabled)
        x4, x8, x16_ref, x32 = self.cp(x)

        if self.use_sp:
            sp8 = self.sp(x)  # /8, C=base

            # For the /16 pre-fusion we need a term analogous to up( reduce(arm32) ).
            # x16_ref already equals post_merge_reduce( arm16 + up(reduce(arm32)) ).
            # To keep the module self-contained, we use x16_ref as the "arm16-like" input
            # and feed zeros for the explicit up32 term (still enables early SP@/16 injection).
            up32_like = torch.zeros_like(x16_ref)
            skip16 = self.pre1(x16_ref, up32_like, sp8) if self.pre1 is not None else x16_ref

            # Optional ultralight residual FFM at /8
            x8p = self.ffm(x8, sp8) if (self.use_ffm_light and self.ffm is not None) else x8
        else:
            skip16 = x16_ref
            x8p = x8

        # Decode with [x4, x8p, skip16, x32]
        logits = self.decoder([x4, x8p, skip16, x32])
        return logits


# ---------- Utils ----------
def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


# ---------- Quick check ----------
# if __name__ == "__main__":
#     net = BiseUNetV6(
#         in_ch=3, out_ch=1, base_ch=32,
#         use_sp=True, use_ffm_light=True,
#         use_peg_lsa_16=True, use_peg_lsa_8=False
#     )
#     x = torch.randn(1, 3, 256, 256)
#     y = net(x)
#     print("out:", y.shape)  # [1,1,256,256]
#     print("params (M):", count_params(net)/1e6)
