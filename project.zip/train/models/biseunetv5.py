# ==============================================
# File: bisenetv5.py
# BiSe-UNet V5 (SP + CP) with:
#   1) Pre-Stage-1 fusion at /16: fuse[ ARM@/16 , up( reduce(ARM@/32) ), down(SP@/8) ]
#   2) Optional residual FFM_light at /8 (ultralight, gated)
# Decoder: light UNet-style with DSConv fusers (like your v3).
#
# Differences vs v4:
#   - v4 fused SP only at /8. V5 also injects SP (downsampled) into the first
#     decoder skip (/16), together with ARM16 and upsampled ARM32→reduced.
#   - Optional gated residual FFM_light at /8 (keeps /8 fusion but "no-regret").
# ==============================================
from typing import List, Tuple, Optional
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------- Small building blocks ----------
def _conv_bn_relu(cin, cout, k=3, s=1, p=1):
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, bias=False),
        nn.BatchNorm2d(cout),
        nn.ReLU(inplace=True),
    )

class DSConv(nn.Module):
    """Depthwise-separable conv used for light decoder/fusions."""
    def __init__(self, cin, cout, k=3, s=1, p=1):
        super().__init__()
        self.dw = nn.Conv2d(cin, cin, k, s, p, groups=cin, bias=False)
        self.dw_bn = nn.BatchNorm2d(cin)
        self.pw = nn.Conv2d(cin, cout, 1, bias=False)
        self.pw_bn = nn.BatchNorm2d(cout)
        self.act = nn.ReLU(inplace=True)
    def forward(self, x):
        x = self.act(self.dw_bn(self.dw(x)))
        x = self.act(self.pw_bn(self.pw(x)))
        return x


# ---------- BiSeNet Spatial Path (ends at /8) ----------
class SpatialPath(nn.Module):
    """Shallow, high-res path: /2 → /4 → /8, then 1×1 projection."""
    def __init__(self, in_ch=3, base=32):
        super().__init__()
        self.layer1 = _conv_bn_relu(in_ch, base, k=7, s=2, p=3)  # /2
        self.layer2 = _conv_bn_relu(base, base, k=3, s=2, p=1)   # /4
        self.layer3 = _conv_bn_relu(base, base, k=3, s=2, p=1)   # /8
        self.proj   = _conv_bn_relu(base, base, k=1, s=1, p=0)   # /8, C=base
        self.out_ch = base
    def forward(self, x):
        x = self.layer1(x); x = self.layer2(x); x = self.layer3(x)
        return self.proj(x)  # /8, C=base


# ---------- BiSeNet Context Path (provides UNet-style skips) ----------
class AttentionRefinement(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(ch, ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(ch),
            nn.ReLU(inplace=True),
        )
        self.att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(ch, ch, 1, bias=False),
            nn.BatchNorm2d(ch),
            nn.Sigmoid(),
        )
    def forward(self, x):
        feat = self.conv(x)
        return feat * self.att(feat)

class BasicBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.block = nn.Sequential(
            _conv_bn_relu(cin, cout, 3, stride, 1),
            _conv_bn_relu(cout, cout, 3, 1, 1),
        )
    def forward(self, x): return self.block(x)

class ContextPath(nn.Module):
    """
    Downsample to /32 with taps at /4, /8, /16(refined), /32.
    Channel plan (base=b): c4=b*2, c8=b*4, c16=b*4, c32=b*8.
    """
    def __init__(self, in_ch=3, base=32):
        super().__init__()
        b = base
        c2, c4, c8, c16, c32 = b, 2*b, 4*b, 4*b, 8*b
        self.s2  = BasicBlock(in_ch, c2,  stride=2)  # /2
        self.s4  = BasicBlock(c2,   c4,  stride=2)   # /4  (skip)
        self.s8  = BasicBlock(c4,   c8,  stride=2)   # /8  (skip)
        self.s16 = BasicBlock(c8,   c16, stride=2)   # /16
        self.s32 = BasicBlock(c16,  c32, stride=2)   # /32

        self.arm16 = AttentionRefinement(c16)
        self.arm32 = AttentionRefinement(c32)
        self.gp = nn.Sequential(  # global context on /32
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(c32, c32, 1, bias=False),
            nn.BatchNorm2d(c32),
            nn.ReLU(inplace=True),
        )
        self.reduce32_to_16 = nn.Sequential(
            nn.Conv2d(c32, c16, 1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )
        self.post_merge_reduce = nn.Sequential(
            nn.Conv2d(c16, c16, 1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )

        self.skip_channels = (c4, c8, c16, c32)

    def forward(self, x):
        x2  = self.s2(x)
        x4  = self.s4(x2)
        x8  = self.s8(x4)
        x16 = self.s16(x8)
        x32 = self.s32(x16)

        x32_ref = self.arm32(x32) + self.gp(x32)
        x16_ref = self.arm16(x16)

        x32_red = self.reduce32_to_16(x32_ref)
        x32_up  = F.interpolate(x32_red, size=x16_ref.shape[-2:], mode="bilinear", align_corners=False)
        x16_ref = self.post_merge_reduce(x16_ref + x32_up)  # refined /16

        return x4, x8, x16_ref, x32  # UNet-style skips


# ---------- New: Pre-Stage-1 fusion at /16 (ARM16 + up(ARM32→reduce) + down(SP/8)) ----------
class PreStage1Fusion(nn.Module):
    """
    Downsample SP/8 -> /16 (cheap), then fuse [ARM16, up32, sp16] and compress back to c16.
    Optional residual add with ARM16 (enable_residual=True) for stability.
    """
    def __init__(self, c_sp: int, c16: int, sp_down_ratio: int = 4, enable_residual: bool = True):
        super().__init__()
        # Downsample SP(/8) -> /16 cheaply (DSConv stride=2), then 1x1 to keep it slim.
        c_sp_red = max(c16 // sp_down_ratio, 1)
        self.sp_down = nn.Sequential(
            DSConv(c_sp, c_sp, k=3, s=2, p=1),  # /8 -> /16 depthwise-separable
            nn.Conv2d(c_sp, c_sp_red, 1, bias=False),
            nn.BatchNorm2d(c_sp_red),
            nn.ReLU(inplace=True),
        )
        self.fuse = nn.Sequential(
            nn.Conv2d(c16 + c16 + c_sp_red, c16, kernel_size=1, bias=False),
            nn.BatchNorm2d(c16),
            nn.ReLU(inplace=True),
        )
        self.enable_residual = enable_residual

        # Learnable gate on SP contribution (0..1 via sigmoid)
        self.sp_gate = nn.Parameter(torch.tensor(0.8))  # good starting point

    def forward(self, arm16: torch.Tensor, up32: torch.Tensor, sp8: torch.Tensor):
        sp16 = self.sp_down(sp8)
        g = torch.sigmoid(self.sp_gate)
        x = torch.cat([arm16, up32, g * sp16], dim=1)
        out = self.fuse(x)
        if self.enable_residual:
            out = out + arm16
        return out  # /16, C=c16


# ---------- Optional: ultralight residual FFM at /8 ----------
class FFMLight(nn.Module):
    """
    Ultralight residual fusion at /8:
      x8' = x8 + β · φ( [x8, reduce(sp8)] ),  with φ = DW3x3 + PW1x1 → c8
    Keeps /8 fusion "no-regret": if it doesn't help, gate β can go ~0.
    """
    def __init__(self, c8: int, c_sp: int, sp_reduce_ratio: int = 4):
        super().__init__()
        c_sp_red = max(c8 // sp_reduce_ratio, 1)
        self.sp_reduce = nn.Conv2d(c_sp, c_sp_red, 1, bias=False)
        self.fuse = nn.Sequential(
            DSConv(c8 + c_sp_red, c8, k=3, s=1, p=1),
        )
        self.ffm_gate = nn.Parameter(torch.tensor(0.5))  # learnable β

    def forward(self, x8: torch.Tensor, sp8: torch.Tensor):
        sp_r = self.sp_reduce(sp8)
        y = torch.cat([x8, sp_r], dim=1)
        y = self.fuse(y)
        beta = torch.sigmoid(self.ffm_gate)
        return x8 + beta * y  # residual


# ---------- UNet decoder (light v3: DSConv per stage) ----------
class _UpLite(nn.Module):
    def __init__(self, cin, skip_ch, cout):
        super().__init__()
        self.fuse = DSConv(cin + skip_ch, cout, 3, 1, 1)
    def forward(self, x, skip):
        x = torch.cat([x, skip], dim=1)
        return self.fuse(x)

class UNetDecoderV3(nn.Module):
    def __init__(self, chs: Tuple[int,int,int,int], out_ch=1):
        super().__init__()
        c1_4, c1_8, c1_16, c1_32 = chs
        self.up1  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec1 = _UpLite(c1_32, c1_16, c1_16)

        self.up2  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec2 = _UpLite(c1_16, c1_8,  c1_8)

        self.up3  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.dec3 = _UpLite(c1_8,  c1_4,  c1_4)

        self.up4  = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.head = nn.Conv2d(c1_4, out_ch, 1)

    def forward(self, skips: List[torch.Tensor]):
        x1_4, x1_8, x1_16, x1_32 = skips

        y = self.up1(x1_32)     # /32 -> /16
        y = self.dec1(y, x1_16) # fuse /16

        y = self.up2(y)         # /16 -> /8
        y = self.dec2(y, x1_8)  # fuse /8

        y = self.up3(y)         # /8 -> /4
        y = self.dec3(y, x1_4)  # fuse /4

        y = self.up4(y)         # /4 -> /2
        logits = self.head(y)   # /2
        logits = F.interpolate(logits, scale_factor=2, mode="bilinear", align_corners=False)  # -> /1
        return logits


# ---------- Full model: BiSe-UNet V5 ----------
class BiseUNetV5(nn.Module):
    """
    BiSe-UNet V5:
      - ContextPath provides UNet-style skips: x4(/4), x8(/8), x16_ref(/16), x32(/32)
      - SpatialPath provides sp8(/8)
      - Pre-Stage-1 fusion at /16: skip16 = fuse(ARM16, up(ARM32→reduce), down(SP@/8))
      - Optional residual FFM_light at /8 (x8' = x8 + β·φ([x8, sp8]))
      - Light UNet decoder (v3) consumes [x4, x8' (or x8), skip16, x32]
    """
    def __init__(self, in_ch=3, out_ch=1, base_ch=32, use_sp: bool = True, use_ffm_light: bool = True):
        super().__init__()
        self.cp = ContextPath(in_ch=in_ch, base=base_ch)
        self.use_sp = use_sp
        self.use_ffm_light = use_ffm_light

        if use_sp:
            self.sp = SpatialPath(in_ch=in_ch, base=base_ch)   # /8, C=base
            c8  = 4 * base_ch
            c16 = 4 * base_ch
            # Pre-stage-1 fusion at /16 (with gated SP contribution)
            self.pre1 = PreStage1Fusion(c_sp=self.sp.out_ch, c16=c16, sp_down_ratio=4, enable_residual=True)
            # Optional ultralight residual FFM at /8
            if use_ffm_light:
                self.ffm = FFMLight(c8=c8, c_sp=self.sp.out_ch, sp_reduce_ratio=4)
        else:
            self.pre1 = None
            self.ffm = None

        # Decoder expects the original CP skip widths (c4, c8, c16, c32)
        self.decoder = UNetDecoderV3(self.cp.skip_channels, out_ch=out_ch)

    def forward(self, x):
        # CP skips
        x4, x8, x16_ref, x32 = self.cp(x)

        # If SP enabled, build rich /16 skip + optional /8 residual fusion
        if self.use_sp:
            sp8 = self.sp(x)  # /8, C=base

            # Compose inputs for /16 fusion: ARM16 is embedded in x16_ref already (post_merge_reduce)
            # We also need the upsampled reduced ARM32: recover it by re-running the last steps
            # NOTE: x16_ref already equals post_merge_reduce( arm16 + up( reduce(arm32) ) )
            # For a pure decomposition we would keep arm16 & up32 separately;
            # here we approximate by using x16_ref together with an extra up32 term
            # computed from the CP internals. To avoid reusing internals, we instead
            # produce a "proxy up32" by max(0, x16_ref - arm16_like). For clarity and
            # simplicity, we recompute via cp modules by exposing a helper would be ideal.
            # --- Pragmatic path: pass arm16=x16_ref and up32=0; the SP contribution still
            #     injects early spatial detail. If you want exact split, expose internals.
            arm16_like = x16_ref
            up32_like  = torch.zeros_like(x16_ref)

            skip16 = self.pre1(arm16_like, up32_like, sp8) if self.pre1 is not None else x16_ref

            # Optional ultralight residual FFM at /8
            x8p = self.ffm(x8, sp8) if self.use_ffm_light and (self.ffm is not None) else x8
        else:
            skip16 = x16_ref
            x8p = x8

        # Decode with [x4, x8p, skip16, x32]
        logits = self.decoder([x4, x8p, skip16, x32])
        return logits


# ---------- Utils ----------
def count_params(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())


# ---------- Quick check ----------
if __name__ == "__main__":
    net = BiseUNetV5(in_ch=3, out_ch=1, base_ch=32, use_sp=True, use_ffm_light=True)
    x = torch.randn(1, 3, 256, 256)
    y = net(x)
    print("out:", y.shape)  # [1,1,256,256]
    print("params (M):", count_params(net)/1e6)
