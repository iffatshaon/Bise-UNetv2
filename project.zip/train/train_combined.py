import os
import argparse
import sys
import time
import json
import torch
import torch.optim as optim
from torch.amp import GradScaler, autocast
from tqdm import tqdm

# Allow imports from parent directory
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from preprocess.dataset_prep import set_seed, list_image_mask_pairs, split_pairs, get_loaders
    from train.models.factory import get_model
    from train.losses.loss_functions import bce_dice_loss
    from train.metrics.metric_functions import seg_metrics_from_logits
except ImportError as e:
    print(f"Import Error: {e}")
    print("Please run this script from the Kvasir-structured directory or set PYTHONPATH.")
    sys.exit(1)

def parse_args():
    parser = argparse.ArgumentParser(description="Combined Dataset Training Script")
    parser.add_argument("--model", type=str, required=True, help="Model architecture name (unet, bisenet, etc.)")
    parser.add_argument("--data-dir", type=str, required=True, help="Path to Combined dataset root")
    parser.add_argument("--out-dir", type=str, required=True, help="Directory to save results")
    parser.add_argument("--epochs", type=int, default=200, help="Max epochs")
    parser.add_argument("--batch", type=int, default=8, help="Batch size")
    parser.add_argument("--lr", type=float, default=1e-3, help="Learning rate")
    parser.add_argument("--img-size", type=int, default=256, help="Image size")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--patience", type=int, default=15, help="Early stopping patience")
    parser.add_argument("--mixed", action="store_true", help="Use mixed precision training")
    parser.add_argument("--workers", type=int, default=4, help="Num workers")
    parser.add_argument("--base-ch", type=int, default=32, help="Base channels for model")
    
    return parser.parse_args()

def train_one_epoch(model, loader, device, opt, scaler, config):
    model.train()
    total_loss, total_dice, total_iou = 0.0, 0.0, 0.0
    n = 0
    
    pbar = tqdm(loader, desc="Train", ncols=100, leave=False)
    for xb, yb in pbar:
        xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
        
        opt.zero_grad(set_to_none=True)
        with autocast('cuda', enabled=config.mixed):
            logits = model(xb)
            loss = bce_dice_loss(logits, yb)
            
        scaler.scale(loss).backward()
        scaler.step(opt)
        scaler.update()
        
        bs = xb.size(0)
        total_loss += loss.item() * bs
        d, i = seg_metrics_from_logits(logits, yb)
        total_dice += d * bs
        total_iou += i * bs
        n += bs
        
        pbar.set_postfix(pts=f"{loss.item():.3f}")

    return total_loss / n, total_dice / n, total_iou / n

@torch.no_grad()
def evaluate(model, loader, device, config):
    model.eval()
    total_loss, total_dice, total_iou = 0.0, 0.0, 0.0
    n = 0
    
    for xb, yb in loader:
        xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
        with autocast('cuda', enabled=config.mixed):
            logits = model(xb)
            loss = bce_dice_loss(logits, yb)
        
        bs = xb.size(0)
        total_loss += loss.item() * bs
        d, i = seg_metrics_from_logits(logits, yb)
        total_dice += d * bs
        total_iou += i * bs
        n += bs
        
    return total_loss / n, total_dice / n, total_iou / n

def main():
    args = parse_args()
    
    os.makedirs(args.out_dir, exist_ok=True)
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    print(f"Loading Combined data from {args.data_dir}...")
    img_dir = os.path.join(args.data_dir, "images")
    msk_dir = os.path.join(args.data_dir, "masks")
    
    # 1. List all pairs
    pairs = list_image_mask_pairs(img_dir, msk_dir)
    print(f"Found {len(pairs)} total pairs.")
    
    # 2. Split
    # Since it's combined, we just do a random split across all data.
    tr, va, te = split_pairs(pairs, seed=args.seed)
    print(f"Split: Train={len(tr)}, Val={len(va)}, Test={len(te)}")
    
    # 3. Loaders
    loader_config = {
        "IMG_SIZE": args.img_size,
        "BATCH": args.batch,
        "AUG_FLIP_H": 0.5, "AUG_FLIP_V": 0.0,
        "AUG_ROTATE_P": 0.2, "AUG_BRIGHTC_P": 0.2,
        "AUG_BRIGHT_A": 0.2, "AUG_BRIGHT_B": 15
    }
    
    train_loader, val_loader, test_loader = get_loaders(tr, va, te, loader_config)
    
    # 4. Model
    print(f"Building model: {args.model}")
    model = get_model(args.model, base_ch=args.base_ch).to(device)
    print(f"Params: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")
    
    # 5. Optimization
    opt = optim.AdamW(model.parameters(), lr=args.lr)
    scaler = GradScaler('cuda', enabled=args.mixed)
    sched = optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", factor=0.5, patience=args.patience//2)
    
    best_dice = -1.0
    no_improve = 0
    history = []
    
    start_time = time.time()
    
    print("\nStarting Training...")
    for epoch in range(1, args.epochs + 1):
        tr_loss, tr_dice, tr_iou = train_one_epoch(model, train_loader, device, opt, scaler, args)
        va_loss, va_dice, va_iou = evaluate(model, val_loader, device, args)
        
        sched.step(va_dice)
        current_lr = opt.param_groups[0]['lr']
        
        print(f"Ep {epoch:03d} | Tr Loss: {tr_loss:.4f} Dice: {tr_dice:.4f} | Va Loss: {va_loss:.4f} Dice: {va_dice:.4f} | LR: {current_lr:.1e}")
        
        hist_entry = {
            "epoch": epoch,
            "train_loss": tr_loss, "train_dice": tr_dice, 
            "val_loss": va_loss, "val_dice": va_dice,
            "lr": current_lr
        }
        history.append(hist_entry)
        
        if va_dice > best_dice:
            best_dice = va_dice
            no_improve = 0
            torch.save({
                'model': model.state_dict(),
                'args': vars(args),
                'best_dice': best_dice,
                'epoch': epoch
            }, os.path.join(args.out_dir, "best.pt"))
            print(f"  --> New Best! Saved to {os.path.join(args.out_dir, 'best.pt')}")
        else:
            no_improve += 1
            if no_improve >= args.patience:
                print(f"Early stopping at epoch {epoch}")
                break
                
        torch.save({
            'model': model.state_dict(), 
            'args': vars(args),
            'epoch': epoch
        }, os.path.join(args.out_dir, "last.pt"))
        
        with open(os.path.join(args.out_dir, "history.json"), "w") as f:
            json.dump(history, f, indent=2)
            
    total_time = time.time() - start_time
    print(f"Training finished in {total_time/60:.1f}m. Best Dice: {best_dice:.4f}")

if __name__ == "__main__":
    main()
